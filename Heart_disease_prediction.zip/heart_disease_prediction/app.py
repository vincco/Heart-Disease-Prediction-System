"""
app.py
------
Streamlit GUI for the Heart Disease Prediction System.

Run:
    streamlit run app.py

Pages
    Overview            project summary, headline numbers, ML lifecycle
    Data Explorer       data audit, distributions, relationships, raw data
    Model Lab           model comparison, test-set evaluation, threshold, explainability
    Patient Segments    unsupervised K-means clustering with PCA projection
    Risk Predictor      single-patient prediction with explanation and what-if analysis
    Batch Prediction    score a CSV of patients and download the results
    About               methodology, limitations and team
"""

from __future__ import annotations

import io
import json
import sys
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
import streamlit as st

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "src"))

import charts as ch  # noqa: E402
from config import (  # noqa: E402
    CLASS_NAMES, CLUSTER_PATH, FEATURE_INFO, FEATURES, MODEL_PATH, NOMINAL_FEATURES,
    BINARY_FEATURES, ORDINAL_FEATURES, NUMERIC_FEATURES, PROJECT_SUBTITLE, PROJECT_TITLE,
    REPORT_PATH, TARGET, TEAM_MEMBERS, decode_value, feature_label,
)
from insights import key_findings, surprising_findings  # noqa: E402
from predict import explain_one, predict_batch, predict_one  # noqa: E402
from preprocess import load_clean, load_raw  # noqa: E402

st.set_page_config(page_title="Heart Disease Prediction", page_icon=":material/cardiology:",
                   layout="wide", initial_sidebar_state="expanded")

# --------------------------------------------------------------------------
# Styling
# --------------------------------------------------------------------------
st.markdown("""
<style>
:root { --ink:#0b0b0b; --ink2:#52514e; --muted:#8a8984; --line:#e8e7e3; --card:#ffffff;
        --blue:#2a78d6; --orange:#eb6834; --good:#0ca30c; --warn:#fab219; --crit:#d03b3b; }
.block-container { padding-top: 2rem; max-width: 1280px; }
h1, h2, h3 { letter-spacing: -0.01em; }
.hero { background: linear-gradient(135deg, #0d366b 0%, #256abf 60%, #3987e5 100%);
        color: #fff; border-radius: 18px; padding: 30px 34px; margin-bottom: 22px; }
.hero h1 { color:#fff; font-size: 2.1rem; margin: 0 0 6px 0; }
.hero p { color: #dce9fb; font-size: 1.02rem; margin: 0; }
.hero .tag { display:inline-block; background: rgba(255,255,255,.16); border-radius: 999px;
             padding: 3px 12px; font-size: .78rem; margin: 12px 6px 0 0; color:#fff; }
.kpi { background: var(--card); border: 1px solid var(--line); border-radius: 14px;
       padding: 16px 18px; height: 100%; }
.kpi .lbl { color: var(--ink2); font-size: .82rem; text-transform: uppercase; letter-spacing: .04em; }
.kpi .val { color: var(--ink); font-size: 1.9rem; font-weight: 700; line-height: 1.2; margin-top: 4px; }
.kpi .sub { color: var(--muted); font-size: .82rem; margin-top: 2px; }
.card { background: var(--card); border: 1px solid var(--line); border-radius: 14px;
        padding: 16px 18px; margin-bottom: 12px; }
.card h4 { margin: 0 0 4px 0; font-size: 1rem; color: var(--ink); }
.card .big { font-size: 1.25rem; font-weight: 700; color: var(--ink); }
.card p { margin: 6px 0 0 0; color: var(--ink2); font-size: .92rem; line-height: 1.5; }
.pill { display:inline-block; border-radius: 999px; padding: 2px 10px; font-size: .75rem;
        font-weight: 600; margin-right: 6px; }
.pill-good { background:#e6f4e6; color:#076307; } .pill-warn { background:#fdf1d6; color:#7a5300; }
.pill-crit { background:#f8e0e0; color:#8f1f1f; } .pill-info { background:#e6effb; color:#184f95; }
.step { text-align:center; background:#f6f8fb; border:1px solid var(--line); border-radius:12px;
        padding:12px 6px; font-size:.85rem; color: var(--ink2); height:100%; }
.step b { display:block; color: var(--ink); font-size: .92rem; margin-bottom: 2px; }
.verdict { border-radius: 14px; padding: 18px 20px; color: var(--ink); }
.disclaimer { background:#fff8e6; border:1px solid #f3dc9c; border-radius: 12px; padding: 12px 16px;
              color:#5c4a12; font-size:.88rem; }
.small { color: var(--muted); font-size: .82rem; }
div[data-testid="stMetricValue"] { font-size: 1.6rem; }
</style>
""", unsafe_allow_html=True)


# --------------------------------------------------------------------------
# Cached loaders
# --------------------------------------------------------------------------
@st.cache_data(show_spinner=False)
def get_data():
    df, audit = load_clean()
    return df, audit.to_dict()


@st.cache_data(show_spinner=False)
def get_raw():
    return load_raw()


@st.cache_data(show_spinner=False)
def get_report():
    if not REPORT_PATH.exists():
        return None
    return json.loads(REPORT_PATH.read_text())


@st.cache_resource(show_spinner=False)
def get_bundle():
    return joblib.load(MODEL_PATH) if MODEL_PATH.exists() else None


@st.cache_resource(show_spinner=False)
def get_cluster_model():
    return joblib.load(CLUSTER_PATH) if CLUSTER_PATH.exists() else None


def kpi(label: str, value: str, sub: str = "") -> str:
    return f"<div class='kpi'><div class='lbl'>{label}</div><div class='val'>{value}</div>" \
           f"<div class='sub'>{sub}</div></div>"


def require_model() -> tuple[dict, dict]:
    report, bundle = get_report(), get_bundle()
    if report is None or bundle is None:
        st.error("The model has not been trained yet. Run `python src/train.py` in a terminal, "
                 "then refresh this page.")
        st.stop()
    return report, bundle


def segment_names(report: dict, df: pd.DataFrame) -> dict[int, str]:
    labels = np.array(report["clusters"]["labels"])
    rates = pd.Series(df[TARGET].values).groupby(labels).mean()
    names = {}
    for c, r in rates.items():
        tier = "Lower-risk" if r < 0.35 else ("Higher-risk" if r > 0.65 else "Mixed-risk")
        names[int(c)] = f"Segment {int(c) + 1}: {tier}"
    return names


df, audit = get_data()


# ==========================================================================
# Page: Overview
# ==========================================================================
def page_overview():
    report, bundle = get_report(), get_bundle()
    st.markdown(f"""
    <div class='hero'>
      <h1>{PROJECT_TITLE}</h1>
      <p>{PROJECT_SUBTITLE}. Built with Python, pandas, scikit-learn, Plotly and Streamlit.</p>
      <span class='tag'>Supervised binary classification</span>
      <span class='tag'>UCI Cleveland dataset</span>
      <span class='tag'>8 models compared with nested cross-validation</span>
      <span class='tag'>Explainable predictions</span>
    </div>""", unsafe_allow_html=True)

    prevalence = df[TARGET].mean() * 100
    cols = st.columns(5)
    cols[0].markdown(kpi("Patients", f"{len(df)}", f"{len(FEATURES)} clinical features"), unsafe_allow_html=True)
    cols[1].markdown(kpi("Heart disease", f"{prevalence:.0f}%", f"{int(df[TARGET].sum())} patients"),
                     unsafe_allow_html=True)
    if report:
        best = report["best_model"]
        m = report["test_results"][best]["metrics"]
        cols[2].markdown(kpi("Best model", best.replace("Support Vector Machine", "SVM"),
                             "chosen by nested CV"), unsafe_allow_html=True)
        cols[3].markdown(kpi("Test accuracy", f"{m['accuracy'] * 100:.1f}%",
                             f"on {report['split']['n_test']} unseen patients"), unsafe_allow_html=True)
        cols[4].markdown(kpi("Test ROC-AUC", f"{m['roc_auc']:.3f}",
                             f"recall {m['recall'] * 100:.0f}%"), unsafe_allow_html=True)
    else:
        cols[2].markdown(kpi("Model", "Not trained", "run src/train.py"), unsafe_allow_html=True)

    st.write("")
    st.subheader("How the system works")
    steps = [("Raw data", "303 patient records"), ("Audit & clean", "duplicates, hidden missing values, label fix"),
             ("Explore", "statistics and charts"), ("Engineer features", "impute, scale, one-hot"),
             ("Train & tune", "8 models, nested CV"), ("Evaluate", "held-out test set"),
             ("Serve", "GUI, batch, REST API")]
    sc = st.columns(len(steps))
    for c, (t, d) in zip(sc, steps):
        c.markdown(f"<div class='step'><b>{t}</b>{d}</div>", unsafe_allow_html=True)

    st.write("")
    left, right = st.columns([1, 1.6])
    with left:
        st.plotly_chart(ch.class_balance_donut(df), use_container_width=True)
    with right:
        st.markdown("#### Top findings from the data")
        for f in key_findings(df)[:4]:
            st.markdown(f"<div class='card'><h4>{f['title']} <span class='pill pill-info'>"
                        f"{f['headline']}</span></h4><p>{f['text']}</p></div>", unsafe_allow_html=True)

    st.markdown("<div class='disclaimer'><b>Important:</b> this is an educational project. "
                "Predictions are statistical estimates from 302 historical patients and are not a "
                "medical diagnosis. Anyone with symptoms should consult a doctor.</div>",
                unsafe_allow_html=True)


# ==========================================================================
# Page: Data Explorer
# ==========================================================================
def page_data():
    st.title("Data Explorer")
    st.caption("Understand the dataset before trusting any model built on it.")
    t_audit, t_dist, t_rel, t_find, t_raw = st.tabs(
        ["Data quality audit", "Feature distributions", "Relationships", "Insights", "Raw data"])

    # ---- Audit -----------------------------------------------------------
    with t_audit:
        c = st.columns(4)
        c[0].markdown(kpi("Raw rows", str(audit["n_rows_raw"])), unsafe_allow_html=True)
        c[1].markdown(kpi("Duplicates removed", str(audit["n_duplicates"])), unsafe_allow_html=True)
        hidden = sum(v["count"] for v in audit["invalid_codes"].values())
        c[2].markdown(kpi("Hidden missing values", str(hidden), "invalid codes set to missing"),
                      unsafe_allow_html=True)
        c[3].markdown(kpi("Clean rows", str(audit["n_rows_clean"])), unsafe_allow_html=True)
        st.write("")

        st.markdown("#### Issue 1: duplicate record")
        st.markdown("One patient appears twice with identical values. Keeping both would let the same "
                    "patient land in both the training and the test set, inflating accuracy. "
                    "**Fix:** dropped the duplicate.")

        st.markdown("#### Issue 2: missing values disguised as numbers")
        st.markdown(
            f"The file reports zero missing values, but `ca` (number of vessels) contains the code **4** "
            f"({audit['invalid_codes']['ca']['count']} rows) although the valid range is 0-3, and `thal` "
            f"contains **0** ({audit['invalid_codes']['thal']['count']} rows) although valid codes are 1-3. "
            "These rows were `?` (missing) in the original UCI file. **Fix:** converted to missing and "
            "imputed with the most frequent value *inside* the model pipeline, so the imputation is "
            "learned only from training data.")

        st.markdown("#### Issue 3: the target label is reversed")
        st.markdown(
            "The dataset documentation says `target = 1` means heart disease. Checking that against "
            "well-established clinical risk factors shows the opposite. In every row below, the "
            "`target = 1` group looks *healthier*:")
        ev = pd.DataFrame(audit["label_evidence"])
        ev["feature"] = ev["feature"].map(feature_label)
        ev.columns = ["Risk indicator", "Mean when target = 1", "Mean when target = 0",
                      "Expected in heart disease", "target = 1 looks"]
        st.dataframe(ev, hide_index=True, use_container_width=True)
        st.markdown(
            "After flipping, the counts match the original UCI Cleveland study exactly "
            f"({int((df[TARGET] == 0).sum())} without disease, {int(df[TARGET].sum())} with disease). "
            "**Fix:** created a corrected column `disease` (1 = heart disease) used throughout. "
            "Without this fix the model would still score well, but every explanation would be "
            "medically backwards, for example claiming exercise-induced chest pain *lowers* risk.")

        st.markdown("#### Issue 4: category codes re-mapped")
        st.markdown("Category codes in this copy differ from the UCI documentation. They were decoded by "
                    "matching category counts to the original study:")
        dec = []
        for f in NOMINAL_FEATURES:
            dec.append({"Feature": feature_label(f),
                        "Codes": ", ".join(f"{k} = {v}" for k, v in FEATURE_INFO[f]["categories"].items())})
        st.dataframe(pd.DataFrame(dec), hide_index=True, use_container_width=True)

    # ---- Distributions ---------------------------------------------------
    with t_dist:
        kind = st.radio("Feature type", ["Measurements", "Categories"], horizontal=True)
        if kind == "Measurements":
            col = st.selectbox("Measurement", NUMERIC_FEATURES, format_func=feature_label)
            a, b = st.columns([1.6, 1])
            a.plotly_chart(ch.numeric_distribution(df, col), use_container_width=True)
            b.plotly_chart(ch.numeric_box(df, col), use_container_width=True)
            stats = df.groupby(TARGET)[col].describe()[["mean", "50%", "std", "min", "max"]]
            stats.index = CLASS_NAMES
            stats.columns = ["Mean", "Median", "Std dev", "Min", "Max"]
            st.dataframe(stats.round(1), use_container_width=True)
        else:
            col = st.selectbox("Category", NOMINAL_FEATURES + BINARY_FEATURES + ORDINAL_FEATURES,
                               format_func=feature_label)
            st.plotly_chart(ch.category_disease_rate(df, col), use_container_width=True)
            st.caption(FEATURE_INFO[col]["help"])

    # ---- Relationships ---------------------------------------------------
    with t_rel:
        st.plotly_chart(ch.target_correlation_bars(df), use_container_width=True)
        st.caption("Category features without a natural order (chest pain type, resting ECG, ST slope, "
                   "thallium) are compared category by category in the Feature distributions tab.")
        a, b = st.columns(2)
        with a:
            st.plotly_chart(ch.age_band_rate(df), use_container_width=True)
        with b:
            x = st.selectbox("X axis", NUMERIC_FEATURES, index=0, format_func=feature_label)
            y = st.selectbox("Y axis", NUMERIC_FEATURES, index=3, format_func=feature_label)
            st.plotly_chart(ch.scatter_two(df, x, y), use_container_width=True)
        with st.expander("Full correlation matrix"):
            st.plotly_chart(ch.correlation_heatmap(df), use_container_width=True)

    # ---- Insights --------------------------------------------------------
    with t_find:
        st.markdown("#### Strongest signals (ranked by effect size)")
        findings = key_findings(df)
        cols = st.columns(2)
        for i, f in enumerate(findings[:8]):
            cols[i % 2].markdown(
                f"<div class='card'><h4>{i + 1}. {f['title']}</h4><div class='big'>{f['headline']}</div>"
                f"<p>{f['text']}</p></div>", unsafe_allow_html=True)
        st.markdown("#### Findings that challenge intuition")
        for s in surprising_findings(df):
            st.markdown(f"<div class='card'><p>{s}</p></div>", unsafe_allow_html=True)

    # ---- Raw data --------------------------------------------------------
    with t_raw:
        view = df.copy()
        decode = st.toggle("Show readable labels instead of codes", value=True)
        if decode:
            for f in FEATURES:
                if "categories" in FEATURE_INFO[f]:
                    view[f] = view[f].apply(lambda v, n=f: "missing" if pd.isna(v) else decode_value(n, v))
            view[TARGET] = view[TARGET].map({0: CLASS_NAMES[0], 1: CLASS_NAMES[1]})
        view = view.rename(columns={f: feature_label(f) for f in FEATURES} | {TARGET: "Diagnosis"})
        st.dataframe(view, use_container_width=True, height=440)
        st.download_button("Download cleaned data (CSV)", df.to_csv(index=False).encode(),
                           "heart_clean.csv", "text/csv")


# ==========================================================================
# Page: Model Lab
# ==========================================================================
def page_models():
    report, bundle = require_model()
    best = report["best_model"]
    st.title("Model Lab")
    st.caption(f"Eight classifiers compared with nested cross-validation "
               f"({report['cv_setup']['outer']} outer folds, {report['cv_setup']['inner']} inside). "
               f"The test set ({report['split']['n_test']} patients) was used only once, at the very end.")

    t_lb, t_test, t_thr, t_exp, t_diag = st.tabs(
        ["Leaderboard", "Test-set results", "Decision threshold", "Explainability", "Diagnostics"])

    lb = pd.DataFrame(report["leaderboard"])

    with t_lb:
        a, b = st.columns([1.3, 1])
        with a:
            metric = st.segmented_control("Metric", ["roc_auc", "f1", "accuracy", "recall", "precision"],
                                          default="roc_auc",
                                          format_func=lambda m: m.replace("_", "-").upper())
            st.plotly_chart(ch.leaderboard_bars(lb, metric or "roc_auc", best), use_container_width=True)
        with b:
            st.markdown(f"<div class='card'><h4>Selected model</h4><div class='big'>{best}</div>"
                        f"<p>Highest mean nested-CV ROC-AUC. Tuned hyper-parameters: "
                        f"<code>{report['best_params'][best]}</code></p></div>", unsafe_allow_html=True)
            top = lb.iloc[0]
            close = lb[lb["cv_roc_auc_mean"] >= top["cv_roc_auc_mean"] - top["cv_roc_auc_std"]]["model"].tolist()
            st.markdown(f"<div class='card'><h4>How decisive is the win?</h4><p>"
                        f"{len(close)} models score within one standard deviation of the winner "
                        f"({', '.join(close)}). On a dataset this small, the top models are statistically "
                        f"very close; the choice matters less than clean data and honest evaluation.</p></div>",
                        unsafe_allow_html=True)
            mc = report["mcnemar"]
            st.markdown(f"<div class='card'><h4>McNemar's test vs Logistic Regression</h4><p>"
                        f"On the test set, the two models disagree on {mc['a_right_b_wrong'] + mc['a_wrong_b_right']} "
                        f"patients (p = {mc['p_value']:.2f}). "
                        f"{'No statistically significant difference.' if mc['p_value'] >= 0.05 else 'The difference is statistically significant.'}"
                        f"</p></div>", unsafe_allow_html=True)
        table = lb[["model"] + [c for c in lb.columns if c.startswith("cv_") and c.endswith("_mean")]].copy()
        for m in ["accuracy", "precision", "recall", "f1", "roc_auc"]:
            table[f"cv_{m}_mean"] = lb[f"cv_{m}_mean"].map("{:.3f}".format) + " ± " + \
                lb[f"cv_{m}_std"].map("{:.3f}".format)
        table.columns = ["Model", "Accuracy", "Precision", "Recall", "F1", "ROC-AUC"]
        st.dataframe(table, hide_index=True, use_container_width=True)

    tr = report["test_results"]
    y_test = np.array(report["y_test"])

    with t_test:
        rows = []
        for name, r in tr.items():
            m = r["metrics"]
            rows.append({"Model": name, "Threshold": r["threshold"], "Accuracy": m["accuracy"],
                         "Precision": m["precision"], "Recall": m["recall"], "Specificity": m["specificity"],
                         "F1": m["f1"], "ROC-AUC": m["roc_auc"], "Brier": m["brier"]})
        tdf = pd.DataFrame(rows).sort_values("ROC-AUC", ascending=False)
        st.dataframe(tdf.style.format({c: "{:.3f}" for c in tdf.columns if c != "Model"})
                     .highlight_max(subset=["Accuracy", "Precision", "Recall", "Specificity", "F1", "ROC-AUC"],
                                    color="#dbe9fa")
                     .highlight_min(subset=["Brier"], color="#dbe9fa"),
                     hide_index=True, use_container_width=True)
        st.caption("Thresholds are chosen per model from training data only (Youden's J). "
                   "Brier score measures probability accuracy; lower is better.")
        a, b = st.columns(2)
        a.plotly_chart(ch.roc_curves(tr, y_test, best), use_container_width=True)
        b.plotly_chart(ch.pr_curves(tr, best, float(y_test.mean())), use_container_width=True)

        st.markdown("#### Confusion matrix")
        sel = st.selectbox("Model", list(tr.keys()), index=list(tr.keys()).index(best))
        a, b = st.columns([1.2, 1])
        a.plotly_chart(ch.confusion_matrix_fig(tr[sel]["metrics"]["confusion_matrix"]), use_container_width=True)
        (tn, fp), (fn, tp) = tr[sel]["metrics"]["confusion_matrix"]
        b.markdown(f"""<div class='card'><h4>Reading the matrix</h4><p>
            Of {tp + fn} test patients who truly had heart disease, the model caught <b>{tp}</b>
            and missed <b>{fn}</b> (false negatives, the costly error in screening).<br><br>
            Of {tn + fp} healthy patients, <b>{tn}</b> were correctly cleared and <b>{fp}</b>
            were flagged for follow-up unnecessarily (false positives).</p></div>""",
                   unsafe_allow_html=True)

    with t_thr:
        st.markdown("A model outputs a probability; the **threshold** turns it into a yes/no decision. "
                    "In screening, missing a sick patient is worse than a false alarm, so a lower "
                    "threshold is often preferred.")
        proba = np.array(tr[best]["proba"])
        thr = st.slider("Decision threshold", 0.05, 0.95, float(round(report["thresholds"][best], 2)), 0.01)
        pred = (proba >= thr).astype(int)
        tp = int(((pred == 1) & (y_test == 1)).sum()); fn = int(((pred == 0) & (y_test == 1)).sum())
        tn = int(((pred == 0) & (y_test == 0)).sum()); fp = int(((pred == 1) & (y_test == 0)).sum())
        c = st.columns(4)
        c[0].metric("Sensitivity (recall)", f"{tp / max(tp + fn, 1) * 100:.0f}%")
        c[1].metric("Specificity", f"{tn / max(tn + fp, 1) * 100:.0f}%")
        c[2].metric("Precision", f"{tp / max(tp + fp, 1) * 100:.0f}%")
        c[3].metric("Missed disease cases", f"{fn}")
        st.plotly_chart(ch.threshold_sweep(y_test, proba, thr), use_container_width=True)

    with t_exp:
        imp = report["importance"]
        a, b = st.columns([1.3, 1])
        a.plotly_chart(ch.permutation_importance_fig(imp["permutation"]), use_container_width=True)
        perm = pd.DataFrame(imp["permutation"]).sort_values("mean", ascending=False)
        top3 = [feature_label(f) for f in perm["feature"].head(3)]
        b.markdown(f"""<div class='card'><h4>What the model relies on</h4><p>
            Permutation importance shuffles one feature at a time and measures how much the test ROC-AUC
            falls. The biggest drops come from <b>{top3[0]}</b>, <b>{top3[1]}</b> and <b>{top3[2]}</b>.
            <br><br>Because it only needs predictions, this method works for any model, including
            kernel SVMs that have no built-in importance scores. Bars near zero (or negative) mean the
            model would do just as well without that feature.</p></div>""", unsafe_allow_html=True)
        if imp.get("native"):
            nat = imp["native"]
            with b.expander("Model's own weights" if nat["type"] == "coefficient" else "Gini importance"):
                st.dataframe(pd.DataFrame({"Feature": nat["features"], "Value": nat["values"]})
                             .sort_values("Value", key=np.abs, ascending=False), hide_index=True)
        st.info("Per-patient explanations are on the Risk Predictor page.")

    with t_diag:
        a, b = st.columns(2)
        a.plotly_chart(ch.learning_curve_fig(report["learning_curve"]), use_container_width=True)
        lc = report["learning_curve"]
        gap = lc["train_mean"][-1] - lc["val_mean"][-1]
        a.caption(f"Gap between training and validation at full size: {gap:.3f}. "
                  + ("A small gap means the model is not over-fitting." if gap < 0.05 else
                     "A noticeable gap suggests some over-fitting; more data would help."))
        b.plotly_chart(ch.calibration_fig(report["calibration"]), use_container_width=True)
        b.caption(f"Out-of-fold Brier score: {report['calibration']['brier_oof']:.3f}. Points near the "
                  "diagonal mean a predicted 70% really does correspond to roughly 70% of patients.")


# ==========================================================================
# Page: Patient Segments
# ==========================================================================
def page_segments():
    report, _ = require_model()
    cl = report["clusters"]
    names = segment_names(report, df)
    st.title("Patient Segments")
    st.caption("Unsupervised learning: K-means groups patients by clinical similarity WITHOUT seeing "
               "the diagnosis. We then check whether the groups line up with heart disease.")

    a, b = st.columns(2)
    a.plotly_chart(ch.elbow_fig(cl["k_scores"], cl["best_k"]), use_container_width=True)
    b.plotly_chart(ch.silhouette_fig(cl["k_scores"], cl["best_k"]), use_container_width=True)
    st.markdown(f"The silhouette score peaks at **k = {cl['best_k']}**, so the patients form "
                f"{cl['best_k']} natural groups.")

    labels = np.array(cl["labels"])
    st.plotly_chart(ch.cluster_scatter(cl["pca_coords"], labels, df[TARGET].values, names,
                                       cl["pca_explained_variance"]), use_container_width=True)

    st.markdown("#### Segment profiles")
    prof_rows = []
    for c in sorted(set(labels)):
        d = df[labels == c]
        prof_rows.append({
            "Segment": names[c], "Patients": len(d),
            "Heart disease rate": f"{d[TARGET].mean() * 100:.0f}%",
            "Avg age": f"{d['age'].mean():.0f}", "Male": f"{d['sex'].mean() * 100:.0f}%",
            "Avg max heart rate": f"{d['thalach'].mean():.0f}",
            "Exercise angina": f"{d['exang'].mean() * 100:.0f}%",
            "Avg ST depression": f"{d['oldpeak'].mean():.2f}",
            "Most common chest pain": decode_value("cp", d["cp"].mode().iloc[0]),
            "Most common thallium": decode_value("thal", d["thal"].mode().iloc[0]),
        })
    st.dataframe(pd.DataFrame(prof_rows), hide_index=True, use_container_width=True)
    purity = max(pd.crosstab(labels, df[TARGET]).max(axis=1).sum() / len(df), 0)
    st.markdown(f"<div class='card'><p>Even without labels, assigning each segment its majority diagnosis "
                f"would be right for <b>{purity * 100:.0f}%</b> of patients. This confirms the clinical "
                f"measurements contain a strong, natural disease signal, which is why the supervised models "
                f"perform well.</p></div>", unsafe_allow_html=True)


# ==========================================================================
# Page: Risk Predictor
# ==========================================================================
def _input_widget(name: str, container, key_prefix: str = "in_"):
    info = FEATURE_INFO[name]
    key = key_prefix + name
    if "categories" in info:
        opts = list(info["categories"].keys())
        if len(opts) == 2 and info["kind"] == "binary":
            return container.radio(info["label"], opts, index=opts.index(info["default"]),
                                   format_func=lambda v: info["categories"][v], horizontal=True,
                                   help=info["help"], key=key)
        return container.selectbox(info["label"], opts, index=opts.index(info["default"]),
                                   format_func=lambda v: info["categories"][v], help=info["help"], key=key)
    is_float = isinstance(info["step"], float)
    return container.number_input(
        f"{info['label']} ({info['unit']})", min_value=info["min"], max_value=info["max"],
        value=float(info["default"]) if is_float else int(info["default"]),
        step=info["step"], help=info["help"], key=key,
        format="%.1f" if is_float else "%d")


EXAMPLES = {
    "Typical healthy profile": dict(age=45, sex=0, cp=2, trestbps=120, chol=210, fbs=0, restecg=1,
                                    thalach=170, exang=0, oldpeak=0.0, slope=2, ca=0, thal=2),
    "High-risk profile": dict(age=63, sex=1, cp=0, trestbps=150, chol=280, fbs=1, restecg=0,
                              thalach=115, exang=1, oldpeak=2.6, slope=1, ca=2, thal=3),
    "Borderline profile": dict(age=56, sex=1, cp=1, trestbps=135, chol=245, fbs=0, restecg=1,
                               thalach=150, exang=0, oldpeak=1.0, slope=1, ca=0, thal=2),
}


def page_predict():
    report, bundle = require_model()
    st.title("Risk Predictor")
    st.caption(f"Enter a patient's clinical measurements. Model: {bundle['model_name']}, "
               f"decision threshold {bundle['threshold']:.2f}.")

    ex = st.segmented_control("Load an example", list(EXAMPLES.keys()), key="example_choice")
    if ex and st.session_state.get("_loaded_example") != ex:
        for k, v in EXAMPLES[ex].items():
            st.session_state["in_" + k] = v if "categories" in FEATURE_INFO[k] else \
                (float(v) if isinstance(FEATURE_INFO[k]["step"], float) else int(v))
        st.session_state["_loaded_example"] = ex
        st.rerun()

    with st.form("patient_form"):
        st.markdown("**Demographics and history**")
        c = st.columns(4)
        patient = {}
        patient["age"] = _input_widget("age", c[0])
        patient["sex"] = _input_widget("sex", c[1])
        patient["cp"] = _input_widget("cp", c[2])
        patient["fbs"] = _input_widget("fbs", c[3])
        st.markdown("**Resting measurements**")
        c = st.columns(4)
        patient["trestbps"] = _input_widget("trestbps", c[0])
        patient["chol"] = _input_widget("chol", c[1])
        patient["restecg"] = _input_widget("restecg", c[2])
        patient["thal"] = _input_widget("thal", c[3])
        st.markdown("**Exercise stress test and imaging**")
        c = st.columns(5)
        patient["thalach"] = _input_widget("thalach", c[0])
        patient["exang"] = _input_widget("exang", c[1])
        patient["oldpeak"] = _input_widget("oldpeak", c[2])
        patient["slope"] = _input_widget("slope", c[3])
        patient["ca"] = _input_widget("ca", c[4])
        submitted = st.form_submit_button("Predict risk", type="primary", use_container_width=True)

    if submitted:
        st.session_state["last_patient"] = patient
    patient = st.session_state.get("last_patient")
    if not patient:
        st.info("Fill in the form (or load an example) and press **Predict risk**.")
        return

    try:
        result = predict_one(patient, bundle)
        contrib = explain_one(patient, bundle)
    except ValueError as exc:
        st.error(f"Please check the inputs: {exc}")
        return

    prob = result["probability"]
    band, color = ch.risk_band(prob)
    st.divider()
    a, b = st.columns([1, 1.3])
    with a:
        st.plotly_chart(ch.risk_gauge(prob, result["threshold"]), use_container_width=True)
        verdict = "flags this patient for heart disease" if result["prediction"] else \
            "does not flag this patient for heart disease"
        pill = {"Low risk": "pill-good", "Moderate risk": "pill-warn", "High risk": "pill-crit"}[band]
        st.markdown(f"<div class='card'><span class='pill {pill}'>{band}</span>"
                    f"<p>The model {verdict} (probability {prob * 100:.1f}% vs threshold "
                    f"{result['threshold'] * 100:.0f}%; the black marker on the gauge).</p></div>",
                    unsafe_allow_html=True)
        cm = get_cluster_model()
        if cm is not None:
            raw_c = int(cm.predict(pd.DataFrame([patient], columns=FEATURES).astype(float))[0])
            seg = cm.cluster_order_.get(raw_c, raw_c)
            st.markdown(f"<div class='card'><h4>Closest patient segment</h4>"
                        f"<p>{segment_names(report, df).get(seg, f'Segment {seg + 1}')}</p></div>",
                        unsafe_allow_html=True)
    with b:
        st.plotly_chart(ch.contribution_fig(contrib), use_container_width=True)
        st.caption("Orange bars push the risk up and blue bars pull it down, compared with a typical "
                   "patient in the dataset. Hover over a bar for the change in percentage points.")
        up = contrib[contrib["impact"] > 0.1].sort_values("impact", ascending=False).head(3)
        down = contrib[contrib["impact"] < -0.1].sort_values("impact").head(3)
        txt = ""
        if len(up):
            txt += "<b>Raising risk:</b> " + "; ".join(f"{r.label} ({r.value_text})" for r in up.itertuples()) + ".<br>"
        if len(down):
            txt += "<b>Lowering risk:</b> " + "; ".join(f"{r.label} ({r.value_text})" for r in down.itertuples()) + "."
        if txt:
            st.markdown(f"<div class='card'><p>{txt}</p></div>", unsafe_allow_html=True)

    st.plotly_chart(ch.percentile_fig(df, patient), use_container_width=True)

    with st.expander("What-if analysis: change one measurement and see the risk move", expanded=False):
        feat = st.selectbox("Measurement to vary", NUMERIC_FEATURES, index=3, format_func=feature_label)
        info = FEATURE_INFO[feat]
        grid = np.linspace(info["min"], info["max"], 60)
        variants = [{**patient, feat: float(v)} for v in grid]
        probs = bundle["pipeline"].predict_proba(pd.DataFrame(variants, columns=FEATURES).astype(float))[:, 1]
        import plotly.graph_objects as go
        fig = go.Figure(go.Scatter(x=grid, y=probs * 100, mode="lines", line=dict(color=ch.SERIES[0], width=2.5),
                                   hovertemplate=f"{info['label']}: %{{x:.1f}}<br>Risk %{{y:.1f}}%<extra></extra>"))
        fig.add_vline(x=patient[feat], line=dict(color=ch.TEXT, dash="dash"),
                      annotation_text="current value")
        fig.add_hline(y=result["threshold"] * 100, line=dict(color=ch.MUTED, dash="dot"),
                      annotation_text="threshold")
        fig.update_xaxes(title=f"{info['label']} ({info['unit']})")
        fig.update_yaxes(title="Predicted risk (%)", range=[0, 100])
        st.plotly_chart(ch._base(fig, None, height=340, legend=False), use_container_width=True)
        st.caption("Holding every other value fixed. This shows what the model learned, not a "
                   "guaranteed medical effect.")

    st.markdown("<div class='disclaimer'>This estimate comes from a statistical model trained on 302 "
                "patients from a single 1988 study. It is not a diagnosis and must not replace a "
                "clinician's judgement.</div>", unsafe_allow_html=True)


# ==========================================================================
# Page: Batch Prediction
# ==========================================================================
def page_batch():
    _, bundle = require_model()
    st.title("Batch Prediction")
    st.caption("Score many patients at once. Upload a CSV with the 13 feature columns using the codes "
               "described in the template.")
    template = pd.DataFrame([EXAMPLES[k] for k in EXAMPLES], columns=FEATURES)
    a, b = st.columns([1, 2])
    a.download_button("Download CSV template", template.to_csv(index=False).encode(),
                      "patients_template.csv", "text/csv", use_container_width=True)
    use_test = a.button("Try it with the 61 test-set patients", use_container_width=True)
    with b.expander("Column codes"):
        st.dataframe(pd.DataFrame([{
            "Column": f, "Meaning": FEATURE_INFO[f]["label"],
            "Allowed values": (", ".join(f"{k}={v}" for k, v in FEATURE_INFO[f]["categories"].items())
                               if "categories" in FEATURE_INFO[f]
                               else f"{FEATURE_INFO[f]['min']} to {FEATURE_INFO[f]['max']} {FEATURE_INFO[f]['unit']}"),
        } for f in FEATURES]), hide_index=True, use_container_width=True)

    up = st.file_uploader("Upload patients CSV", type=["csv"])
    data = None
    if up is not None:
        try:
            data = pd.read_csv(up)
        except Exception as exc:  # noqa: BLE001 - surface any parse error to the user
            st.error(f"Could not read the file: {exc}")
            return
    elif use_test or st.session_state.get("batch_test"):
        st.session_state["batch_test"] = True
        report = get_report()
        data = df.loc[report["test_index"], FEATURES + [TARGET]].copy()
        data[FEATURES] = data[FEATURES].fillna(df[FEATURES].mode().iloc[0])
    if data is None:
        return

    try:
        out = predict_batch(data, bundle)
    except ValueError as exc:
        st.error(str(exc))
        return

    ok = out[out["error"] == ""]
    c = st.columns(4)
    c[0].markdown(kpi("Patients scored", str(len(ok)), f"{len(out) - len(ok)} rows with errors"),
                  unsafe_allow_html=True)
    c[1].markdown(kpi("Flagged", str(int((ok["prediction"] == "Heart disease").sum()))), unsafe_allow_html=True)
    c[2].markdown(kpi("Average risk", f"{ok['risk_probability'].mean() * 100:.0f}%"), unsafe_allow_html=True)
    if TARGET in out.columns:
        acc = ((ok["prediction"] == "Heart disease").astype(int) == ok[TARGET]).mean()
        c[3].markdown(kpi("Accuracy vs known labels", f"{acc * 100:.1f}%"), unsafe_allow_html=True)
    st.write("")

    import plotly.graph_objects as go
    fig = go.Figure()
    if TARGET in out.columns:
        for cls in (0, 1):
            fig.add_trace(go.Histogram(x=ok.loc[ok[TARGET] == cls, "risk_probability"] * 100,
                                       name=f"Actually: {CLASS_NAMES[cls]}", marker_color=ch.CLASS_COLORS[cls],
                                       xbins=dict(start=0, end=100, size=5), opacity=0.8))
        fig.update_layout(barmode="stack")
    else:
        fig.add_trace(go.Histogram(x=ok["risk_probability"] * 100, marker_color=ch.SERIES[0],
                                   xbins=dict(start=0, end=100, size=5)))
    fig.add_vline(x=bundle["threshold"] * 100, line=dict(color=ch.TEXT, dash="dash"),
                  annotation_text="threshold")
    fig.update_xaxes(title="Predicted risk (%)")
    fig.update_yaxes(title="Patients")
    st.plotly_chart(ch._base(fig, "Distribution of predicted risk", height=340), use_container_width=True)

    show = out.copy()
    show.insert(0, "risk_%", (show.pop("risk_probability") * 100).round(1))
    st.dataframe(show, use_container_width=True, height=380,
                 column_config={"risk_%": st.column_config.ProgressColumn("Risk %", min_value=0, max_value=100,
                                                                          format="%.1f%%")})
    buf = io.StringIO()
    out.to_csv(buf, index=False)
    st.download_button("Download results (CSV)", buf.getvalue().encode(), "heart_predictions.csv", "text/csv",
                       type="primary")


# ==========================================================================
# Page: About
# ==========================================================================
def page_about():
    report = get_report()
    st.title("About this project")
    a, b = st.columns([1.5, 1])
    with a:
        st.markdown("""
#### Objective
Predict whether a patient is likely to have heart disease from 13 routine clinical measurements,
and present the analysis in a form that non-specialists can understand.

#### Dataset
UCI Cleveland Heart Disease dataset (Detrano et al., 1988): 303 patients referred for coronary
angiography at the Cleveland Clinic. Heart disease = more than 50% narrowing of a major vessel.

#### Methodology
1. **Audit and cleaning**: removed a duplicate, recovered 7 hidden missing values, corrected the
   reversed target label and decoded category codes.
2. **Exploratory analysis**: distributions, disease rates by category, correlations and
   plain-language findings.
3. **Preprocessing pipeline**: median / most-frequent imputation, standard scaling and one-hot
   encoding inside a scikit-learn `Pipeline`, so training and prediction use identical steps.
4. **Model comparison**: Logistic Regression, K-Nearest Neighbours, SVM, Naive Bayes, Decision Tree,
   Random Forest, Gradient Boosting and a soft-voting ensemble, compared with nested cross-validation.
5. **Evaluation**: accuracy, precision, recall, specificity, F1, ROC-AUC, PR-AUC, Brier score,
   confusion matrix, McNemar's test, learning curve and calibration curve.
6. **Explainability**: permutation importance (global) and counterfactual contributions (per patient).
7. **Unsupervised analysis**: K-means segmentation (k by silhouette), visualised with PCA.
8. **Deployment**: this Streamlit GUI, batch CSV scoring, a FastAPI REST endpoint and a CLI.

#### Limitations
* Only 302 patients from one hospital in 1988; results may not generalise to other populations.
* Few women (32%) and few patients under 40, so predictions for these groups are less certain.
* The patients were already referred for cardiac testing, so the "healthy" group is not the
  general public.
* Educational tool only. Not validated for clinical use.
""")
    with b:
        st.markdown("#### Team")
        for name, roll in TEAM_MEMBERS:
            st.markdown(f"<div class='card'><h4>{name}</h4><p>{roll}</p></div>", unsafe_allow_html=True)
        st.markdown("#### Technology")
        st.markdown("<div class='card'><p>Python, pandas, NumPy, scikit-learn, SciPy, Plotly, Matplotlib, "
                    "Seaborn, Streamlit, FastAPI, joblib</p></div>", unsafe_allow_html=True)
        if report:
            st.markdown(f"<p class='small'>Model trained {report['generated_at']} in "
                        f"{report['train_seconds']} s.</p>", unsafe_allow_html=True)


# --------------------------------------------------------------------------
# Navigation
# --------------------------------------------------------------------------
pages = [
    st.Page(page_overview, title="Overview", icon=":material/home:", default=True),
    st.Page(page_data, title="Data Explorer", icon=":material/query_stats:", url_path="data"),
    st.Page(page_models, title="Model Lab", icon=":material/model_training:", url_path="models"),
    st.Page(page_segments, title="Patient Segments", icon=":material/scatter_plot:", url_path="segments"),
    st.Page(page_predict, title="Risk Predictor", icon=":material/monitor_heart:", url_path="predict"),
    st.Page(page_batch, title="Batch Prediction", icon=":material/upload_file:", url_path="batch"),
    st.Page(page_about, title="About", icon=":material/info:", url_path="about"),
]
with st.sidebar:
    st.markdown(f"### {PROJECT_TITLE}")
    st.caption("Machine Learning course project")
nav = st.navigation(pages)
with st.sidebar:
    st.divider()
    st.caption("Educational use only. Not a medical device.")
nav.run()
