# Heart Disease Prediction System

A machine-learning system that estimates a patient's likelihood of heart disease from 13 routine
clinical measurements. It includes a full data audit, exploratory analysis, comparison of eight
classifiers with nested cross-validation, explainable predictions, unsupervised patient
segmentation, and an interactive Streamlit GUI.

> Educational project only. Not a medical device and not a substitute for a doctor's diagnosis.

---

## Quick start

```bash
pip install -r requirements.txt
python src/train.py           # about 1-4 minutes; creates model/ artefacts
streamlit run app.py          # opens the GUI at http://localhost:8501
```

The trained model is already included in `model/`, so `streamlit run app.py` also works
straight away. Re-run `src/train.py` whenever the data or code changes.

Optional:

```bash
python src/report_figures.py  # static Matplotlib/Seaborn figures for the report -> reports/figures/
python src/predict.py         # command-line predictor
uvicorn src.api:app --reload  # REST API, docs at http://127.0.0.1:8000/docs
```

---

## The GUI

| Page | What it shows |
|---|---|
| **Overview** | Headline numbers, the ML pipeline, diagnosis split, top findings |
| **Data Explorer** | Data-quality audit, distributions by diagnosis, disease rate per category, correlations, plain-language insights, raw data download |
| **Model Lab** | Leaderboard (nested CV), test-set metrics, ROC and precision-recall curves, confusion matrix, interactive threshold slider, permutation importance, learning curve, calibration |
| **Patient Segments** | K-means clustering (elbow and silhouette), PCA scatter, segment profiles |
| **Risk Predictor** | Patient form with example profiles, risk gauge, per-patient explanation, percentile comparison, what-if analysis |
| **Batch Prediction** | Upload a CSV, score every patient, download results |
| **About** | Methodology, limitations, team |

---

## Project structure

```
heart_disease_prediction/
├── app.py                      Streamlit GUI (entry point)
├── data/heart.csv              UCI Cleveland dataset (Kaggle export, 303 rows)
├── model/                      trained pipeline, cluster model, training_report.json
├── reports/figures/            static figures for the written report
├── src/
│   ├── config.py               paths, feature dictionary, category decoding
│   ├── preprocess.py           audit, cleaning, preprocessing transformer
│   ├── train.py                model comparison, tuning, evaluation, clustering
│   ├── predict.py              validation, prediction, per-patient explanation, CLI
│   ├── charts.py               Plotly chart builders used by the GUI
│   ├── insights.py             data-driven plain-language findings
│   ├── report_figures.py       Matplotlib/Seaborn exports
│   └── api.py                  FastAPI REST endpoint
├── .streamlit/config.toml      GUI theme
└── requirements.txt
```

---

## Data audit: what was wrong with the dataset and how it was fixed

| Issue | Evidence | Fix |
|---|---|---|
| Duplicate row | 1 identical record | Dropped (302 patients remain) |
| Hidden missing values | `ca` = 4 in 5 rows (valid 0-3); `thal` = 0 in 2 rows (valid 1-3) | Set to missing; imputed inside the pipeline using training data only |
| **Reversed target label** | The `target = 1` group is younger, more often female, has less exercise angina, less ST depression, fewer blocked vessels and higher max heart rate. All six indicators point to *healthy* | Created `disease = 1 - target`. Counts now match the original UCI study: 164 healthy, 138 diseased |
| Re-mapped category codes | Category counts differ from the UCI documentation | Decoded by matching counts to the original study (see `config.py`) |

Without the label fix the model's accuracy would be unchanged, but every explanation would be
medically backwards (for example "exercise-induced angina lowers risk").

---

## Methodology

1. **Split**: stratified 80/20 split (241 training, 61 test patients). The test set is used once.
2. **Preprocessing pipeline**: median / most-frequent imputation, standard scaling, one-hot
   encoding for nominal categories. It is bundled with the model in one `Pipeline`, so the GUI
   and API apply exactly the same steps as training (no training-serving skew).
3. **Models**: Logistic Regression (L1/L2), K-Nearest Neighbours, SVM (RBF), Gaussian Naive Bayes,
   Decision Tree (with cost-complexity pruning), Random Forest, Gradient Boosting, and a
   soft-voting ensemble.
4. **Nested cross-validation**: an inner 5-fold GridSearchCV tunes the hyper-parameters, and an
   outer 5-fold x 3-repeat loop measures performance. This avoids the optimistic bias of tuning and
   scoring on the same folds.
5. **Selection**: highest mean outer-fold ROC-AUC.
6. **Threshold**: Youden's J statistic on out-of-fold training probabilities.
7. **Evaluation**: accuracy, precision, recall, specificity, F1, ROC-AUC, PR-AUC, Brier score,
   confusion matrix, and McNemar's test against the logistic-regression baseline.
8. **Diagnostics**: learning curve and reliability (calibration) diagram.
9. **Explainability**: permutation importance (global); counterfactual "typical patient"
   contributions in log-odds (per patient).
10. **Unsupervised**: K-means on the preprocessed features, with k chosen by silhouette score and
    the result shown in 2-D with PCA.

## Results

| Model | Nested-CV ROC-AUC | Test accuracy | Test recall | Test ROC-AUC |
|---|---|---|---|---|
| **Support Vector Machine (selected)** | **0.912 ± 0.041** | **85.2%** | 78.6% | 0.911 |
| Logistic Regression | 0.910 ± 0.041 | 85.2% | 78.6% | 0.920 |
| Naive Bayes | 0.909 ± 0.036 | 85.2% | 85.7% | 0.907 |
| Soft-Voting Ensemble | 0.909 ± 0.039 | 82.0% | 67.9% | 0.907 |
| Random Forest | 0.906 ± 0.044 | 80.3% | 67.9% | 0.889 |
| Gradient Boosting | 0.900 ± 0.044 | 82.0% | 75.0% | 0.908 |
| K-Nearest Neighbours | 0.891 ± 0.054 | 78.7% | 71.4% | 0.905 |
| Decision Tree | 0.823 ± 0.063 | 78.7% | 71.4% | 0.834 |

The top models are within one standard deviation of each other. On 302 patients, about 85%
accuracy is close to the realistic ceiling reported for this dataset. Claims of 95%+ usually come
from evaluating on training data or from leakage.

Most important features: number of narrowed vessels (`ca`), chest pain type, ST depression,
maximum heart rate and the thallium test.

---

## Likely viva questions

**Why nested cross-validation?** If you tune and score on the same folds, the score is biased
upward because you picked the best of many tries. Nested CV keeps the tuning inside and the
scoring outside.

**Why ROC-AUC for model selection rather than accuracy?** It is threshold-independent and
measures how well the model ranks sick patients above healthy ones. The threshold is chosen
separately.

**Why is recall important here?** A false negative means a sick patient is sent home. The Model
Lab's threshold slider shows how lowering the threshold raises recall at the cost of more false
alarms.

**Why does cholesterol matter so little?** Every patient was already referred for cardiac
testing, so high cholesterol is common in both groups. The stress-test features separate them
much better.

**Why not a deep neural network?** On small tabular datasets, linear, kernel and tree models
match or beat neural networks and are easier to interpret.

**How is training-serving skew prevented?** Imputation, scaling and encoding are part of the saved
`Pipeline`, so prediction uses the identical fitted transformations.

## Dataset

Detrano, R. et al. (1989). UCI Machine Learning Repository: Heart Disease (Cleveland).
