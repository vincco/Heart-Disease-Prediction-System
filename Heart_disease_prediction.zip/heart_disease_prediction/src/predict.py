"""
predict.py
----------
Inference utilities shared by the GUI, the REST API and the command line.

* load_artifacts()   - load the trained pipeline bundle once
* validate_patient() - type/range checks with clear error messages
* predict_one()      - probability + label for one patient
* predict_batch()    - probabilities for a DataFrame of patients
* explain_one()      - per-feature contribution to this patient's risk

Run interactively:
    python src/predict.py
"""

from __future__ import annotations

import sys
from functools import lru_cache
from pathlib import Path

import joblib
import numpy as np
import pandas as pd

sys.path.append(str(Path(__file__).resolve().parent))
from config import FEATURE_INFO, FEATURES, MODEL_PATH, decode_value  # noqa: E402


class ModelNotTrainedError(FileNotFoundError):
    """Raised when the model artefact has not been created yet."""


@lru_cache(maxsize=1)
def load_artifacts(path: str = str(MODEL_PATH)) -> dict:
    if not Path(path).exists():
        raise ModelNotTrainedError(
            f"Trained model not found at {path}. Run 'python src/train.py' first."
        )
    return joblib.load(path)


def validate_patient(patient: dict) -> dict:
    """Return a clean copy of `patient`, raising ValueError on any invalid field."""
    clean, errors = {}, []
    for name in FEATURES:
        info = FEATURE_INFO[name]
        if name not in patient or patient[name] is None or patient[name] == "":
            errors.append(f"'{name}' ({info['label']}) is missing")
            continue
        try:
            value = float(patient[name])
        except (TypeError, ValueError):
            errors.append(f"'{name}' must be a number, got {patient[name]!r}")
            continue
        if "categories" in info:
            if int(value) not in info["categories"] or value != int(value):
                allowed = ", ".join(f"{k}={v}" for k, v in info["categories"].items())
                errors.append(f"'{name}' must be one of: {allowed}")
                continue
        elif not info["min"] <= value <= info["max"]:
            errors.append(f"'{name}' must be between {info['min']} and {info['max']}")
            continue
        clean[name] = value
    if errors:
        raise ValueError("; ".join(errors))
    return clean


def _frame(patients: list[dict]) -> pd.DataFrame:
    return pd.DataFrame(patients, columns=FEATURES).astype(float)


def predict_one(patient: dict, bundle: dict | None = None) -> dict:
    """Predict a single patient. Returns probability, label and the threshold used."""
    bundle = bundle or load_artifacts()
    clean = validate_patient(patient)
    prob = float(bundle["pipeline"].predict_proba(_frame([clean]))[0, 1])
    return {
        "probability": prob,
        "prediction": int(prob >= bundle["threshold"]),
        "threshold": float(bundle["threshold"]),
        "model": bundle["model_name"],
    }


def predict_batch(df: pd.DataFrame, bundle: dict | None = None) -> pd.DataFrame:
    """
    Score many patients. Rows that fail validation are kept and annotated in an
    'error' column instead of aborting the whole batch.
    """
    bundle = bundle or load_artifacts()
    missing = [c for c in FEATURES if c not in df.columns]
    if missing:
        raise ValueError(f"Uploaded file is missing columns: {', '.join(missing)}")

    out = df.copy()
    probs, errors = [], []
    valid_rows, valid_idx = [], []
    for idx, row in df[FEATURES].iterrows():
        try:
            valid_rows.append(validate_patient(row.to_dict()))
            valid_idx.append(idx)
            errors.append("")
        except ValueError as exc:
            errors.append(str(exc))
    prob_map = {}
    if valid_rows:
        p = bundle["pipeline"].predict_proba(_frame(valid_rows))[:, 1]
        prob_map = dict(zip(valid_idx, p))
    for idx in df.index:
        probs.append(prob_map.get(idx, np.nan))
    out["risk_probability"] = np.round(probs, 4)
    out["prediction"] = [
        "" if np.isnan(p) else ("Heart disease" if p >= bundle["threshold"] else "No disease")
        for p in probs
    ]
    out["error"] = errors
    return out


def explain_one(patient: dict, bundle: dict | None = None) -> pd.DataFrame:
    """
    Model-agnostic, per-patient explanation.

    For each feature, replace this patient's value with the value of a typical
    patient (median for measurements, most common category otherwise) and record
    how much the prediction changes. A positive value means this patient's value
    RAISES their risk relative to a typical patient.

    Two scales are returned:
      delta  - change in probability (intuitive, but compresses near 0% and 100%)
      impact - change in log-odds (does not saturate, so it is used for ranking
               and for the chart even when the risk is very high or very low)
    """
    bundle = bundle or load_artifacts()
    clean = validate_patient(patient)
    ref = bundle["reference_profile"]
    pipe = bundle["pipeline"]
    base_prob = float(pipe.predict_proba(_frame([clean]))[0, 1])

    variants = []
    for name in FEATURES:
        v = dict(clean)
        v[name] = ref[name]
        variants.append(v)
    probs = pipe.predict_proba(_frame(variants))[:, 1]

    eps = 1e-6

    def logit(x: float) -> float:
        x = min(max(x, eps), 1 - eps)
        return float(np.log(x / (1 - x)))

    rows = []
    for name, p in zip(FEATURES, probs):
        unit = FEATURE_INFO[name].get("unit", "")
        fmt = (lambda x: f"{x:g} {unit}".strip()) if "categories" not in FEATURE_INFO[name] \
            else (lambda x, n=name: decode_value(n, x))
        rows.append({
            "feature": name,
            "label": FEATURE_INFO[name]["label"],
            "value_text": fmt(clean[name]),
            "reference_text": fmt(ref[name]),
            "delta": base_prob - float(p),
            "impact": logit(base_prob) - logit(float(p)),
        })
    return pd.DataFrame(rows)


def _interactive() -> None:
    print("=" * 60)
    print(" Heart Disease Risk Prediction (command line)")
    print("=" * 60)
    patient = {}
    for name in FEATURES:
        info = FEATURE_INFO[name]
        if "categories" in info:
            options = ", ".join(f"{k}={v}" for k, v in info["categories"].items())
            prompt = f"{info['label']} [{options}]: "
        else:
            prompt = f"{info['label']} ({info.get('unit', '')}, {info['min']}-{info['max']}): "
        while True:
            raw = input(prompt).strip()
            try:
                validate_patient({**{f: FEATURE_INFO[f]["default"] for f in FEATURES}, name: raw})
                patient[name] = float(raw)
                break
            except ValueError as exc:
                print(f"  Invalid: {exc}")
    result = predict_one(patient)
    print("-" * 60)
    print(f" Model: {result['model']}")
    print(f" Estimated probability of heart disease: {result['probability'] * 100:.1f}%")
    verdict = "Heart disease likely" if result["prediction"] else "Heart disease unlikely"
    print(f" Result (threshold {result['threshold']:.2f}): {verdict}")
    print("-" * 60)
    print(" Educational tool only - not a medical diagnosis.")


if __name__ == "__main__":
    _interactive()
