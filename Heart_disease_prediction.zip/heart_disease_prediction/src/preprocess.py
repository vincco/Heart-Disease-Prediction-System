"""
preprocess.py
-------------
Data loading, auditing, cleaning and the reusable preprocessing transformer.

Pipeline stages
    raw CSV -> audit (data-quality report) -> clean (dedupe, invalid codes -> NaN,
    corrected target) -> train/test split -> ColumnTransformer (impute, scale, encode)

The ColumnTransformer is embedded inside every model Pipeline, so imputation and
scaling statistics are learned only from the training folds. This avoids test-set
leakage and guarantees that the GUI and API apply exactly the same transformation
that was used during training.
"""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler

from config import (
    BINARY_FEATURES, DATA_PATH, FEATURES, INVALID_CODES, NOMINAL_FEATURES,
    NUMERIC_FEATURES, ORDINAL_FEATURES, RANDOM_STATE, RAW_TARGET, TARGET, TEST_SIZE,
)

# Healthy-direction indicators used to verify which raw label means "disease".
# For each, the clinical literature says the value is higher in diseased patients
# (+1) or lower in diseased patients (-1).
_CLINICAL_DIRECTION = {
    "age": +1,        # older patients carry more risk
    "sex": +1,        # male sex is a risk factor
    "exang": +1,      # exercise-induced angina indicates ischaemia
    "oldpeak": +1,    # larger ST depression indicates ischaemia
    "ca": +1,         # more narrowed vessels indicates disease
    "thalach": -1,    # lower achievable heart rate indicates poorer function
}


@dataclass
class AuditReport:
    """Structured summary of every data-quality issue found and how it was handled."""

    n_rows_raw: int
    n_cols_raw: int
    n_duplicates: int
    n_missing_explicit: int
    invalid_codes: dict = field(default_factory=dict)
    label_evidence: list = field(default_factory=list)
    label_inverted: bool = False
    n_rows_clean: int = 0

    def to_dict(self) -> dict:
        return {
            "n_rows_raw": self.n_rows_raw,
            "n_cols_raw": self.n_cols_raw,
            "n_duplicates": self.n_duplicates,
            "n_missing_explicit": self.n_missing_explicit,
            "invalid_codes": self.invalid_codes,
            "label_evidence": self.label_evidence,
            "label_inverted": self.label_inverted,
            "n_rows_clean": self.n_rows_clean,
        }


def load_raw(csv_path=DATA_PATH) -> pd.DataFrame:
    """Load the dataset exactly as shipped (handles a UTF-8 byte-order mark)."""
    df = pd.read_csv(csv_path, encoding="utf-8-sig")
    df.columns = [c.strip() for c in df.columns]
    missing_cols = set(FEATURES + [RAW_TARGET]) - set(df.columns)
    if missing_cols:
        raise ValueError(f"Dataset is missing required columns: {sorted(missing_cols)}")
    return df


def _detect_label_inversion(df: pd.DataFrame) -> tuple[bool, list]:
    """
    Decide whether raw `target == 1` actually denotes the healthy group.

    For each clinically established risk indicator, compare the group means of
    target==1 and target==0. If the majority of indicators point the "healthy"
    way for target==1, the label is inverted relative to its documentation.
    """
    evidence = []
    votes_inverted = 0
    for col, direction in _CLINICAL_DIRECTION.items():
        mean_t1 = float(df.loc[df[RAW_TARGET] == 1, col].mean())
        mean_t0 = float(df.loc[df[RAW_TARGET] == 0, col].mean())
        # If target==1 were "disease", we would expect sign(mean_t1 - mean_t0) == direction.
        consistent_with_doc = np.sign(mean_t1 - mean_t0) == direction
        if not consistent_with_doc:
            votes_inverted += 1
        evidence.append({
            "feature": col,
            "mean_target_1": round(mean_t1, 2),
            "mean_target_0": round(mean_t0, 2),
            "expected_in_disease": "higher" if direction > 0 else "lower",
            "target_1_looks_like": "disease" if consistent_with_doc else "healthy",
        })
    inverted = votes_inverted > len(_CLINICAL_DIRECTION) / 2
    return inverted, evidence


def audit_dataset(df: pd.DataFrame) -> AuditReport:
    """Run all data-quality checks without modifying the data."""
    invalid = {}
    for col, codes in INVALID_CODES.items():
        mask = df[col].isin(codes)
        invalid[col] = {"codes": codes, "count": int(mask.sum())}
    inverted, evidence = _detect_label_inversion(df)
    return AuditReport(
        n_rows_raw=int(df.shape[0]),
        n_cols_raw=int(df.shape[1]),
        n_duplicates=int(df.duplicated().sum()),
        n_missing_explicit=int(df.isna().sum().sum()),
        invalid_codes=invalid,
        label_evidence=evidence,
        label_inverted=inverted,
    )


def clean_data(df: pd.DataFrame, audit: AuditReport | None = None) -> pd.DataFrame:
    """
    Apply the fixes identified by the audit:
      1. drop exact duplicate rows,
      2. convert invalid category codes to NaN (they were missing values in the source),
      3. create the corrected binary target `disease` (1 = heart disease present).
    Missing values are NOT filled here; imputation happens inside the model pipeline.
    """
    if audit is None:
        audit = audit_dataset(df)
    out = df.drop_duplicates().reset_index(drop=True).copy()
    for col, codes in INVALID_CODES.items():
        out[col] = out[col].astype(float)
        out.loc[out[col].isin(codes), col] = np.nan
    out[TARGET] = (1 - out[RAW_TARGET]) if audit.label_inverted else out[RAW_TARGET]
    out[TARGET] = out[TARGET].astype(int)
    out = out.drop(columns=[RAW_TARGET])
    audit.n_rows_clean = int(out.shape[0])
    return out


def load_clean(csv_path=DATA_PATH) -> tuple[pd.DataFrame, AuditReport]:
    """Convenience wrapper: load, audit and clean in one call."""
    raw = load_raw(csv_path)
    audit = audit_dataset(raw)
    return clean_data(raw, audit), audit


def split_data(df: pd.DataFrame, test_size: float = TEST_SIZE, random_state: int = RANDOM_STATE):
    """Stratified hold-out split. The test set is never used for any modelling decision."""
    X = df[FEATURES]
    y = df[TARGET]
    return train_test_split(X, y, test_size=test_size, random_state=random_state, stratify=y)


def build_preprocessor(scale_numeric: bool = True) -> ColumnTransformer:
    """
    Build the feature transformer.

    numeric  : median imputation, then standardisation (z-score)
    ordinal  : most-frequent imputation, then standardisation
    binary   : most-frequent imputation, passed through as 0/1
    nominal  : most-frequent imputation, then one-hot encoding

    Tree models do not need scaling, but scaling is harmless for them and keeping
    one transformer for every model keeps the comparison fair and the code simple.
    """
    num_steps = [("impute", SimpleImputer(strategy="median"))]
    ord_steps = [("impute", SimpleImputer(strategy="most_frequent"))]
    if scale_numeric:
        num_steps.append(("scale", StandardScaler()))
        ord_steps.append(("scale", StandardScaler()))

    return ColumnTransformer(
        transformers=[
            ("num", Pipeline(num_steps), NUMERIC_FEATURES),
            ("ord", Pipeline(ord_steps), ORDINAL_FEATURES),
            ("bin", SimpleImputer(strategy="most_frequent"), BINARY_FEATURES),
            ("nom", Pipeline([
                ("impute", SimpleImputer(strategy="most_frequent")),
                ("onehot", OneHotEncoder(handle_unknown="ignore", sparse_output=False)),
            ]), NOMINAL_FEATURES),
        ],
        verbose_feature_names_out=False,
    )


if __name__ == "__main__":
    clean, report = load_clean()
    print("Data audit")
    print("-" * 40)
    for key, value in report.to_dict().items():
        if key != "label_evidence":
            print(f"{key:20s}: {value}")
    print("\nLabel orientation evidence:")
    print(pd.DataFrame(report.label_evidence).to_string(index=False))
    print(f"\nClean shape: {clean.shape}")
    print(clean[TARGET].value_counts().rename(index={0: 'No disease', 1: 'Heart disease'}))
    print("\nMissing values after cleaning:\n", clean.isna().sum()[lambda s: s > 0])
