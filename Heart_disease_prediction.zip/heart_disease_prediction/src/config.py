"""
config.py
---------
Central configuration for the Heart Disease Prediction System.

Holds file paths, the feature dictionary (human-readable names, units,
valid ranges and category decodings) and project metadata. Every other
module imports from here so that training, the GUI and the API all agree
on exactly the same feature definitions (this prevents training-serving skew).
"""

from __future__ import annotations

from pathlib import Path

# --------------------------------------------------------------------------
# Paths
# --------------------------------------------------------------------------
ROOT_DIR = Path(__file__).resolve().parent.parent
DATA_PATH = ROOT_DIR / "data" / "heart.csv"
MODEL_DIR = ROOT_DIR / "model"
REPORT_DIR = ROOT_DIR / "reports"
FIGURE_DIR = REPORT_DIR / "figures"

MODEL_PATH = MODEL_DIR / "heart_disease_pipeline.joblib"
REPORT_PATH = MODEL_DIR / "training_report.json"
CLUSTER_PATH = MODEL_DIR / "cluster_model.joblib"

# --------------------------------------------------------------------------
# Project metadata (edit to match your team)
# --------------------------------------------------------------------------
PROJECT_TITLE = "Heart Disease Prediction System"
PROJECT_SUBTITLE = "Machine-learning risk assessment from routine clinical measurements"
TEAM_MEMBERS = [
    ("Hrushika Habeeb", "2520090054"),
]

RANDOM_STATE = 42
TEST_SIZE = 0.20
CV_FOLDS = 5
CV_REPEATS = 3

# --------------------------------------------------------------------------
# Target
# --------------------------------------------------------------------------
RAW_TARGET = "target"        # column as shipped in the CSV
TARGET = "disease"           # corrected label used everywhere: 1 = heart disease
CLASS_NAMES = ["No disease", "Heart disease"]

# --------------------------------------------------------------------------
# Feature groups (drive the preprocessing ColumnTransformer)
# --------------------------------------------------------------------------
NUMERIC_FEATURES = ["age", "trestbps", "chol", "thalach", "oldpeak"]
ORDINAL_FEATURES = ["ca"]
BINARY_FEATURES = ["sex", "fbs", "exang"]
NOMINAL_FEATURES = ["cp", "restecg", "slope", "thal"]

FEATURES = [
    "age", "sex", "cp", "trestbps", "chol", "fbs", "restecg",
    "thalach", "exang", "oldpeak", "slope", "ca", "thal",
]

# Codes that are not valid clinical values in this copy of the dataset.
# In the original UCI Cleveland file these rows contained "?" (missing);
# the Kaggle export silently replaced "?" with an out-of-range integer.
INVALID_CODES = {"ca": [4], "thal": [0]}

# --------------------------------------------------------------------------
# Feature dictionary
# Category decodings follow the original UCI documentation, re-mapped to the
# integer codes used in this file (verified by matching category counts
# against the original Cleveland data; see preprocess.audit_dataset).
# --------------------------------------------------------------------------
FEATURE_INFO: dict[str, dict] = {
    "age": {
        "label": "Age", "unit": "years", "kind": "numeric",
        "min": 18, "max": 100, "default": 54, "step": 1,
        "help": "Patient age in years.",
    },
    "sex": {
        "label": "Sex", "kind": "binary",
        "categories": {0: "Female", 1: "Male"}, "default": 1,
        "help": "Biological sex of the patient.",
    },
    "cp": {
        "label": "Chest pain type", "kind": "nominal",
        "categories": {
            0: "Asymptomatic",
            1: "Atypical angina",
            2: "Non-anginal pain",
            3: "Typical angina",
        },
        "default": 0,
        "help": ("Type of chest pain reported. Clinically, 'asymptomatic' patients "
                 "who are referred for testing are the highest-risk group in this data."),
    },
    "trestbps": {
        "label": "Resting blood pressure", "unit": "mm Hg", "kind": "numeric",
        "min": 80, "max": 220, "default": 130, "step": 1,
        "healthy": (90, 120),
        "help": "Systolic blood pressure on admission to hospital.",
    },
    "chol": {
        "label": "Serum cholesterol", "unit": "mg/dl", "kind": "numeric",
        "min": 100, "max": 600, "default": 240, "step": 1,
        "healthy": (125, 200),
        "help": "Total serum cholesterol.",
    },
    "fbs": {
        "label": "Fasting blood sugar > 120 mg/dl", "kind": "binary",
        "categories": {0: "No", 1: "Yes"}, "default": 0,
        "help": "Whether fasting blood sugar exceeds 120 mg/dl.",
    },
    "restecg": {
        "label": "Resting ECG", "kind": "nominal",
        "categories": {
            0: "Left ventricular hypertrophy",
            1: "Normal",
            2: "ST-T wave abnormality",
        },
        "default": 1,
        "help": "Result of the resting electrocardiogram.",
    },
    "thalach": {
        "label": "Maximum heart rate", "unit": "bpm", "kind": "numeric",
        "min": 60, "max": 220, "default": 150, "step": 1,
        "help": "Highest heart rate reached during the exercise stress test.",
    },
    "exang": {
        "label": "Exercise-induced angina", "kind": "binary",
        "categories": {0: "No", 1: "Yes"}, "default": 0,
        "help": "Whether exercise brought on chest pain.",
    },
    "oldpeak": {
        "label": "ST depression (oldpeak)", "unit": "mm", "kind": "numeric",
        "min": 0.0, "max": 7.0, "default": 0.8, "step": 0.1,
        "help": "ST-segment depression induced by exercise relative to rest.",
    },
    "slope": {
        "label": "ST slope at peak exercise", "kind": "nominal",
        "categories": {0: "Downsloping", 1: "Flat", 2: "Upsloping"},
        "default": 2,
        "help": "Shape of the ST segment at peak exercise. Upsloping is the healthy pattern.",
    },
    "ca": {
        "label": "Major vessels coloured (fluoroscopy)", "kind": "ordinal",
        "categories": {0: "0", 1: "1", 2: "2", 3: "3"}, "default": 0,
        "help": "Number of major coronary vessels (0-3) showing narrowing on fluoroscopy.",
    },
    "thal": {
        "label": "Thallium stress test", "kind": "nominal",
        "categories": {1: "Fixed defect", 2: "Normal", 3: "Reversible defect"},
        "default": 2,
        "help": "Result of the thallium heart scan.",
    },
}


def feature_label(name: str) -> str:
    """Return the human-readable label for a feature (falls back to the raw name)."""
    info = FEATURE_INFO.get(name)
    return info["label"] if info else name


def decode_value(name: str, value) -> str:
    """Translate an encoded category value to its readable label."""
    info = FEATURE_INFO.get(name, {})
    cats = info.get("categories")
    if cats is None:
        return str(value)
    try:
        return cats.get(int(value), str(value))
    except (TypeError, ValueError):
        return str(value)
