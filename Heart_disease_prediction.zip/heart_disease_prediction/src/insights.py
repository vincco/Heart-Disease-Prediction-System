"""
insights.py
-----------
Turns the cleaned dataset into plain-language findings for the GUI.
Every sentence is computed from the data, so the text stays correct if the
dataset is replaced or extended.
"""

from __future__ import annotations

import pandas as pd

from config import FEATURE_INFO, NOMINAL_FEATURES, BINARY_FEATURES, ORDINAL_FEATURES, TARGET, decode_value


def _rate(series: pd.Series) -> float:
    return float(series.mean() * 100)


def category_extremes(df: pd.DataFrame, col: str, min_count: int = 10) -> dict:
    g = df.groupby(col)[TARGET].agg(["mean", "count"])
    g = g[g["count"] >= min_count]
    hi, lo = g["mean"].idxmax(), g["mean"].idxmin()
    return {
        "col": col,
        "high_label": decode_value(col, hi), "high_rate": g.loc[hi, "mean"] * 100,
        "high_n": int(g.loc[hi, "count"]),
        "low_label": decode_value(col, lo), "low_rate": g.loc[lo, "mean"] * 100,
        "low_n": int(g.loc[lo, "count"]),
        "ratio": (g.loc[hi, "mean"] / g.loc[lo, "mean"]) if g.loc[lo, "mean"] > 0 else float("inf"),
    }


def numeric_gap(df: pd.DataFrame, col: str) -> dict:
    d = df.groupby(TARGET)[col].mean()
    return {"col": col, "healthy": float(d.loc[0]), "disease": float(d.loc[1]),
            "diff": float(d.loc[1] - d.loc[0])}


def key_findings(df: pd.DataFrame) -> list[dict]:
    """Return the strongest findings, each with a title, a sentence and a strength score."""
    findings = []
    overall = _rate(df[TARGET])

    for col in NOMINAL_FEATURES + BINARY_FEATURES + ORDINAL_FEATURES:
        ext = category_extremes(df, col)
        gap = ext["high_rate"] - ext["low_rate"]
        findings.append({
            "title": FEATURE_INFO[col]["label"],
            "headline": f"{ext['high_rate']:.0f}% vs {ext['low_rate']:.0f}%",
            "text": (f"Patients with <b>{FEATURE_INFO[col]['label'].lower()}: {ext['high_label']}</b> "
                     f"had heart disease {ext['high_rate']:.0f}% of the time (n={ext['high_n']}), "
                     f"compared with {ext['low_rate']:.0f}% for <b>{ext['low_label']}</b> "
                     f"(n={ext['low_n']})."),
            "strength": gap,
        })

    for col, better in (("thalach", "lower"), ("oldpeak", "higher"), ("age", "higher")):
        g = numeric_gap(df, col)
        unit = FEATURE_INFO[col].get("unit", "")
        findings.append({
            "title": FEATURE_INFO[col]["label"],
            "headline": f"{g['disease']:.1f} vs {g['healthy']:.1f} {unit}",
            "text": (f"Average {FEATURE_INFO[col]['label'].lower()} was <b>{g['disease']:.1f} {unit}</b> "
                     f"in patients with heart disease versus {g['healthy']:.1f} {unit} in those "
                     f"without."),
            "strength": abs(df[[col, TARGET]].corr().iloc[0, 1]) * 100,
        })

    findings.sort(key=lambda f: f["strength"], reverse=True)
    for f in findings:
        f["overall"] = overall
    return findings


def surprising_findings(df: pd.DataFrame) -> list[str]:
    """Findings that challenge intuition - useful talking points for a viva."""
    out = []
    chol = numeric_gap(df, "chol")
    out.append(
        f"Cholesterol barely separates the groups here (average {chol['disease']:.0f} vs "
        f"{chol['healthy']:.0f} mg/dl). Every patient in this study was already referred for "
        f"cardiac testing, so many 'healthy' patients also have high cholesterol."
    )
    bp = numeric_gap(df, "trestbps")
    out.append(
        f"Resting blood pressure differs by only {abs(bp['diff']):.1f} mm Hg between the groups; "
        f"the stress-test measurements (heart rate, ST depression, angina) are far more telling."
    )
    cp = category_extremes(df, "cp")
    out.append(
        f"'{cp['high_label']}' patients had the highest disease rate ({cp['high_rate']:.0f}%). "
        f"Patients without classic chest pain who are still sent for testing are often the "
        f"ones with silent coronary disease."
    )
    fbs = df.groupby("fbs")[TARGET].mean() * 100
    out.append(
        f"High fasting blood sugar shows almost no difference in disease rate "
        f"({fbs.get(1, 0):.0f}% vs {fbs.get(0, 0):.0f}%) in this sample of 302 patients."
    )
    return out
