"""
train.py
--------
End-to-end model development for the Heart Disease Prediction System.

Steps
  1. Load, audit and clean the data (preprocess.py).
  2. Stratified 80/20 hold-out split. The test set is locked away until step 6.
  3. Compare eight candidate classifiers with NESTED cross-validation:
       inner loop  -> GridSearchCV picks hyper-parameters,
       outer loop  -> unbiased estimate of how the tuned model generalises.
  4. Select the winner by mean outer-fold ROC-AUC (threshold independent).
  5. Re-tune the winner on the full training set, then choose a decision
     threshold from out-of-fold probabilities (Youden's J statistic).
  6. Evaluate every tuned model ONCE on the held-out test set.
  7. Diagnostics: learning curve, calibration (reliability) curve, permutation
     importance, McNemar's test against the logistic-regression baseline.
  8. Unsupervised view: K-means patient segments (k chosen by silhouette) + PCA.
  9. Save the fitted pipeline and a JSON report consumed by the GUI.

Run:
    python src/train.py
"""

from __future__ import annotations

import json
import sys
import time
import warnings
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
from scipy.stats import binomtest
from sklearn.base import clone
from sklearn.calibration import calibration_curve
from sklearn.cluster import KMeans
from sklearn.decomposition import PCA
from sklearn.ensemble import (
    GradientBoostingClassifier, RandomForestClassifier, VotingClassifier,
)
from sklearn.inspection import permutation_importance
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    accuracy_score, average_precision_score, brier_score_loss, confusion_matrix,
    f1_score, precision_recall_curve, precision_score, recall_score, roc_auc_score,
    roc_curve, silhouette_score,
)
from sklearn.model_selection import (
    GridSearchCV, RepeatedStratifiedKFold, StratifiedKFold, cross_val_predict,
    cross_validate, learning_curve,
)
from sklearn.naive_bayes import GaussianNB
from sklearn.neighbors import KNeighborsClassifier
from sklearn.pipeline import Pipeline
from sklearn.svm import SVC
from sklearn.tree import DecisionTreeClassifier

sys.path.append(str(Path(__file__).resolve().parent))
from config import (  # noqa: E402
    CLUSTER_PATH, CV_FOLDS, CV_REPEATS, FEATURES, MODEL_DIR, MODEL_PATH,
    RANDOM_STATE, REPORT_PATH, TARGET,
)
from preprocess import build_preprocessor, load_clean, split_data  # noqa: E402

warnings.filterwarnings("ignore", category=UserWarning)
warnings.filterwarnings("ignore", category=FutureWarning)

SCORING = {
    "accuracy": "accuracy",
    "precision": "precision",
    "recall": "recall",
    "f1": "f1",
    "roc_auc": "roc_auc",
}
BASELINE_MODEL = "Logistic Regression"


# --------------------------------------------------------------------------
# Candidate models
# --------------------------------------------------------------------------
def candidate_models() -> dict[str, tuple[object, dict]]:
    """
    Return {name: (estimator, param_grid)}. Grid keys are prefixed with 'clf__'
    because each estimator lives inside a Pipeline(preprocess -> clf).
    """
    rs = RANDOM_STATE
    return {
        "Logistic Regression": (
            LogisticRegression(max_iter=5000, solver="liblinear", random_state=rs),
            {"clf__C": [0.01, 0.03, 0.1, 0.3, 1, 3], "clf__penalty": ["l1", "l2"]},
        ),
        "K-Nearest Neighbours": (
            KNeighborsClassifier(),
            {"clf__n_neighbors": [5, 9, 15, 21, 27], "clf__weights": ["uniform", "distance"]},
        ),
        "Support Vector Machine": (
            SVC(kernel="rbf", probability=True, random_state=rs),
            {"clf__C": [0.1, 0.3, 1, 3], "clf__gamma": ["scale", 0.01, 0.03]},
        ),
        "Naive Bayes": (
            GaussianNB(),
            {"clf__var_smoothing": [1e-9, 1e-6, 1e-3, 1e-1]},
        ),
        "Decision Tree": (
            DecisionTreeClassifier(random_state=rs),
            {"clf__max_depth": [2, 3, 4, 5, 6], "clf__min_samples_leaf": [1, 5, 10],
             "clf__ccp_alpha": [0.0, 0.01]},
        ),
        "Random Forest": (
            RandomForestClassifier(n_estimators=200, random_state=rs, n_jobs=1),
            {"clf__max_depth": [4, None], "clf__min_samples_leaf": [2, 5]},
        ),
        "Gradient Boosting": (
            GradientBoostingClassifier(random_state=rs),
            {"clf__n_estimators": [100, 200], "clf__learning_rate": [0.05],
             "clf__max_depth": [1, 2], "clf__subsample": [0.8]},
        ),
        "Soft-Voting Ensemble": (
            VotingClassifier(
                estimators=[
                    ("lr", LogisticRegression(max_iter=5000, C=0.1, random_state=rs)),
                    ("svm", SVC(kernel="rbf", C=1, probability=True, random_state=rs)),
                    ("rf", RandomForestClassifier(n_estimators=200, max_depth=5,
                                                  min_samples_leaf=3, random_state=rs)),
                ],
                voting="soft",
            ),
            {},  # fixed, sensible defaults; still scored with the same outer CV
        ),
    }


def make_pipeline(estimator) -> Pipeline:
    return Pipeline([("prep", build_preprocessor()), ("clf", clone(estimator))])


def make_search(estimator, grid: dict, cv) -> GridSearchCV | Pipeline:
    pipe = make_pipeline(estimator)
    if not grid:
        return pipe
    return GridSearchCV(pipe, grid, scoring="roc_auc", cv=cv, n_jobs=-1, refit=True)


# --------------------------------------------------------------------------
# Metric helpers
# --------------------------------------------------------------------------
def classification_metrics(y_true, y_proba, threshold: float = 0.5) -> dict:
    y_pred = (y_proba >= threshold).astype(int)
    tn, fp, fn, tp = confusion_matrix(y_true, y_pred, labels=[0, 1]).ravel()
    return {
        "accuracy": accuracy_score(y_true, y_pred),
        "precision": precision_score(y_true, y_pred, zero_division=0),
        "recall": recall_score(y_true, y_pred, zero_division=0),
        "specificity": tn / (tn + fp) if (tn + fp) else 0.0,
        "f1": f1_score(y_true, y_pred, zero_division=0),
        "roc_auc": roc_auc_score(y_true, y_proba),
        "pr_auc": average_precision_score(y_true, y_proba),
        "brier": brier_score_loss(y_true, y_proba),
        "confusion_matrix": [[int(tn), int(fp)], [int(fn), int(tp)]],
    }


def mcnemar_exact(y_true, pred_a, pred_b) -> dict:
    """Exact McNemar test on the discordant pairs of two classifiers."""
    a_right = pred_a == y_true
    b_right = pred_b == y_true
    b = int(np.sum(a_right & ~b_right))   # A right, B wrong
    c = int(np.sum(~a_right & b_right))   # A wrong, B right
    n = b + c
    p_value = 1.0 if n == 0 else binomtest(min(b, c), n, 0.5).pvalue
    return {"a_right_b_wrong": b, "a_wrong_b_right": c, "p_value": float(p_value)}


def to_jsonable(obj):
    """Recursively convert numpy types so the report can be written as JSON."""
    if isinstance(obj, dict):
        return {str(k): to_jsonable(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [to_jsonable(v) for v in obj]
    if isinstance(obj, np.ndarray):
        return to_jsonable(obj.tolist())
    if isinstance(obj, (np.integer,)):
        return int(obj)
    if isinstance(obj, (np.floating,)):
        return None if np.isnan(obj) else float(obj)
    if isinstance(obj, float) and np.isnan(obj):
        return None
    return obj


# --------------------------------------------------------------------------
# Stages
# --------------------------------------------------------------------------
def nested_cv_comparison(X_train, y_train) -> pd.DataFrame:
    """Unbiased model comparison: tuning inside, evaluation outside."""
    inner = StratifiedKFold(n_splits=CV_FOLDS, shuffle=True, random_state=RANDOM_STATE)
    outer = RepeatedStratifiedKFold(n_splits=CV_FOLDS, n_repeats=CV_REPEATS,
                                    random_state=RANDOM_STATE + 1)
    rows = []
    for name, (est, grid) in candidate_models().items():
        t0 = time.time()
        search = make_search(est, grid, inner)
        scores = cross_validate(search, X_train, y_train, cv=outer,
                                scoring=SCORING, n_jobs=-1 if not grid else 1)
        row = {"model": name, "fit_seconds": round(time.time() - t0, 1)}
        for metric in SCORING:
            vals = scores[f"test_{metric}"]
            row[f"cv_{metric}_mean"] = float(np.mean(vals))
            row[f"cv_{metric}_std"] = float(np.std(vals))
        rows.append(row)
        print(f"  {name:24s} ROC-AUC {row['cv_roc_auc_mean']:.3f} +/- {row['cv_roc_auc_std']:.3f}"
              f"   F1 {row['cv_f1_mean']:.3f}   ({row['fit_seconds']}s)")
    table = pd.DataFrame(rows).sort_values(
        ["cv_roc_auc_mean", "cv_f1_mean"], ascending=False
    ).reset_index(drop=True)
    return table


def fit_tuned_models(X_train, y_train) -> tuple[dict, dict]:
    """Tune every candidate on the full training set (repeated CV inside GridSearch)."""
    cv = StratifiedKFold(n_splits=CV_FOLDS, shuffle=True, random_state=RANDOM_STATE)
    fitted, params = {}, {}
    for name, (est, grid) in candidate_models().items():
        search = make_search(est, grid, cv)
        search.fit(X_train, y_train)
        if isinstance(search, GridSearchCV):
            fitted[name] = search.best_estimator_
            params[name] = {k.replace("clf__", ""): v for k, v in search.best_params_.items()}
        else:
            fitted[name] = search
            params[name] = {"note": "fixed configuration (LR C=0.1, SVM C=1, RF depth 5)"}
    return fitted, params


def choose_threshold(model, X_train, y_train) -> tuple[float, np.ndarray]:
    """Pick the threshold maximising Youden's J on out-of-fold training probabilities."""
    cv = StratifiedKFold(n_splits=CV_FOLDS, shuffle=True, random_state=RANDOM_STATE)
    oof = cross_val_predict(clone(model), X_train, y_train, cv=cv, method="predict_proba")[:, 1]
    fpr, tpr, thr = roc_curve(y_train, oof)
    j = tpr - fpr
    best = int(np.argmax(j))
    threshold = float(np.clip(thr[best], 0.05, 0.95))
    return threshold, oof


def test_set_evaluation(fitted: dict, X_test, y_test, thresholds: dict) -> dict:
    results = {}
    for name, model in fitted.items():
        proba = model.predict_proba(X_test)[:, 1]
        thr = thresholds.get(name, 0.5)
        fpr, tpr, _ = roc_curve(y_test, proba)
        prec, rec, _ = precision_recall_curve(y_test, proba)
        results[name] = {
            "threshold": thr,
            "metrics": classification_metrics(y_test, proba, thr),
            "metrics_at_0_5": classification_metrics(y_test, proba, 0.5),
            "roc_curve": {"fpr": fpr, "tpr": tpr},
            "pr_curve": {"precision": prec, "recall": rec},
            "proba": proba,
        }
    return results


def learning_curve_data(model, X_train, y_train) -> dict:
    cv = RepeatedStratifiedKFold(n_splits=CV_FOLDS, n_repeats=2, random_state=RANDOM_STATE)
    sizes, train_scores, val_scores = learning_curve(
        clone(model), X_train, y_train, cv=cv, scoring="roc_auc",
        train_sizes=np.linspace(0.2, 1.0, 8), n_jobs=-1,
    )
    return {
        "train_sizes": sizes,
        "train_mean": train_scores.mean(axis=1), "train_std": train_scores.std(axis=1),
        "val_mean": val_scores.mean(axis=1), "val_std": val_scores.std(axis=1),
    }


def importance_data(model, X_test, y_test) -> dict:
    perm = permutation_importance(model, X_test, y_test, scoring="roc_auc",
                                  n_repeats=30, random_state=RANDOM_STATE, n_jobs=-1)
    perm_df = pd.DataFrame({
        "feature": FEATURES,
        "mean": perm.importances_mean,
        "std": perm.importances_std,
    }).sort_values("mean", ascending=False)

    native = None
    clf = model.named_steps["clf"]
    names = model.named_steps["prep"].get_feature_names_out()
    if hasattr(clf, "coef_"):
        native = {"type": "coefficient", "features": list(names), "values": clf.coef_[0]}
    elif hasattr(clf, "feature_importances_"):
        native = {"type": "gini", "features": list(names), "values": clf.feature_importances_}
    return {"permutation": perm_df.to_dict(orient="list"), "native": native}


def clustering_analysis(df: pd.DataFrame) -> tuple[dict, Pipeline]:
    """K-means patient segmentation on preprocessed clinical features (target excluded)."""
    X = df[FEATURES]
    prep = build_preprocessor().fit(X)
    Z = prep.transform(X)

    k_scores = []
    for k in range(2, 7):
        km = KMeans(n_clusters=k, n_init=20, random_state=RANDOM_STATE).fit(Z)
        k_scores.append({"k": k, "inertia": float(km.inertia_),
                         "silhouette": float(silhouette_score(Z, km.labels_))})
    best_k = max(k_scores, key=lambda r: r["silhouette"])["k"]

    pipe = Pipeline([("prep", build_preprocessor()),
                     ("kmeans", KMeans(n_clusters=best_k, n_init=20, random_state=RANDOM_STATE))])
    labels = pipe.fit_predict(X)
    pca = PCA(n_components=2, random_state=RANDOM_STATE).fit(Z)
    coords = pca.transform(Z)

    # Re-order clusters so that cluster 0 has the lowest disease rate (stable naming).
    rates = pd.Series(df[TARGET].values).groupby(labels).mean().sort_values()
    remap = {old: new for new, old in enumerate(rates.index)}
    labels = np.array([remap[l] for l in labels])
    pipe.cluster_order_ = remap  # stored so the GUI can map new patients identically

    return {
        "k_scores": k_scores,
        "best_k": best_k,
        "labels": labels,
        "pca_coords": coords,
        "pca_explained_variance": pca.explained_variance_ratio_,
    }, pipe


# --------------------------------------------------------------------------
# Main
# --------------------------------------------------------------------------
def main() -> None:
    t_start = time.time()
    print("[1/9] Loading and auditing data")
    df, audit = load_clean()
    X_train, X_test, y_train, y_test = split_data(df)
    print(f"      {audit.n_rows_raw} raw rows -> {len(df)} clean rows; "
          f"train {len(X_train)}, test {len(X_test)}")

    print("[2/9] Nested cross-validation comparison (this takes a minute)")
    leaderboard = nested_cv_comparison(X_train, y_train)
    best_name = leaderboard.loc[0, "model"]
    print(f"      Selected model: {best_name}")

    print("[3/9] Tuning all models on the full training set")
    fitted, best_params = fit_tuned_models(X_train, y_train)

    print("[4/9] Choosing decision thresholds from out-of-fold probabilities")
    thresholds, oof_best = {}, None
    for name, model in fitted.items():
        thr, oof = choose_threshold(model, X_train, y_train)
        thresholds[name] = thr
        if name == best_name:
            oof_best = oof
    print(f"      {best_name} threshold = {thresholds[best_name]:.3f}")

    print("[5/9] Evaluating on the untouched test set")
    test_results = test_set_evaluation(fitted, X_test, y_test, thresholds)
    for name, res in test_results.items():
        m = res["metrics"]
        print(f"      {name:24s} acc {m['accuracy']:.3f}  rec {m['recall']:.3f}  "
              f"f1 {m['f1']:.3f}  auc {m['roc_auc']:.3f}")

    print("[6/9] Statistical comparison vs baseline (McNemar)")
    best_pred = (test_results[best_name]["proba"] >= thresholds[best_name]).astype(int)
    base_pred = (test_results[BASELINE_MODEL]["proba"] >= thresholds[BASELINE_MODEL]).astype(int)
    mcnemar = mcnemar_exact(y_test.values, best_pred, base_pred)
    mcnemar.update({"model_a": best_name, "model_b": BASELINE_MODEL})
    print(f"      p-value = {mcnemar['p_value']:.3f}")

    print("[7/9] Diagnostics: learning curve, calibration, feature importance")
    best_model = fitted[best_name]
    lc = learning_curve_data(best_model, X_train, y_train)
    frac_pos, mean_pred = calibration_curve(y_train, oof_best, n_bins=8, strategy="quantile")
    calibration = {"fraction_positive": frac_pos, "mean_predicted": mean_pred,
                   "brier_oof": brier_score_loss(y_train, oof_best)}
    importance = importance_data(best_model, X_test, y_test)

    print("[8/9] Unsupervised patient segmentation")
    clusters, cluster_pipe = clustering_analysis(df)
    print(f"      best k = {clusters['best_k']}")

    print("[9/9] Saving artefacts")
    MODEL_DIR.mkdir(parents=True, exist_ok=True)
    joblib.dump({
        "pipeline": best_model,
        "model_name": best_name,
        "threshold": thresholds[best_name],
        "features": FEATURES,
        "best_params": best_params[best_name],
        "reference_profile": {  # typical values used for per-patient explanations
            c: (float(df[c].median()) if c in ["age", "trestbps", "chol", "thalach", "oldpeak"]
                else float(df[c].mode().iloc[0]))
            for c in FEATURES
        },
    }, MODEL_PATH)
    joblib.dump(cluster_pipe, CLUSTER_PATH)

    report = {
        "generated_at": time.strftime("%Y-%m-%d %H:%M"),
        "audit": audit.to_dict(),
        "split": {"n_train": len(X_train), "n_test": len(X_test),
                  "train_pos_rate": float(y_train.mean()), "test_pos_rate": float(y_test.mean())},
        "cv_setup": {"outer": f"{CV_FOLDS}-fold x {CV_REPEATS} repeats",
                     "inner": f"{CV_FOLDS}-fold GridSearchCV (ROC-AUC)"},
        "leaderboard": leaderboard.to_dict(orient="records"),
        "best_model": best_name,
        "best_params": best_params,
        "thresholds": thresholds,
        "test_results": {k: {kk: vv for kk, vv in v.items()} for k, v in test_results.items()},
        "y_test": y_test.values,
        "test_index": X_test.index.values,
        "mcnemar": mcnemar,
        "learning_curve": lc,
        "calibration": calibration,
        "importance": importance,
        "clusters": clusters,
        "train_seconds": round(time.time() - t_start, 1),
    }
    REPORT_PATH.write_text(json.dumps(to_jsonable(report), indent=1))
    print(f"      Saved {MODEL_PATH.name}, {CLUSTER_PATH.name}, {REPORT_PATH.name}")
    print(f"Done in {report['train_seconds']}s")


if __name__ == "__main__":
    main()
