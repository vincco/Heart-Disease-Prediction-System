"""
report_figures.py
-----------------
Exports static, print-ready figures (Matplotlib + Seaborn) for the project
report and presentation slides. The interactive versions live in the GUI.

Run after training:
    python src/report_figures.py
Output: reports/figures/*.png
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402
import seaborn as sns  # noqa: E402

sys.path.append(str(Path(__file__).resolve().parent))
from config import (  # noqa: E402
    CLASS_NAMES, FIGURE_DIR, NOMINAL_FEATURES, NUMERIC_FEATURES, REPORT_PATH, TARGET,
    decode_value, feature_label,
)
from preprocess import load_clean  # noqa: E402

BLUE, ORANGE = "#2a78d6", "#eb6834"
PALETTE = {CLASS_NAMES[0]: BLUE, CLASS_NAMES[1]: ORANGE}
SERIES = ["#2a78d6", "#eb6834", "#1baf7a", "#eda100", "#e87ba4", "#008300", "#6250d6", "#e34948"]


def _save(fig, name: str) -> None:
    fig.tight_layout()
    fig.savefig(FIGURE_DIR / name, dpi=180, bbox_inches="tight")
    plt.close(fig)
    print(f"  saved {name}")


def eda_figures(df: pd.DataFrame) -> None:
    d = df.copy()
    d["Diagnosis"] = d[TARGET].map({0: CLASS_NAMES[0], 1: CLASS_NAMES[1]})

    fig, ax = plt.subplots(figsize=(5, 4))
    sns.countplot(data=d, x="Diagnosis", hue="Diagnosis", palette=PALETTE, legend=False, ax=ax)
    for p in ax.patches:
        ax.annotate(f"{int(p.get_height())}", (p.get_x() + p.get_width() / 2, p.get_height()),
                    ha="center", va="bottom")
    ax.set_title("Class distribution"); ax.set_xlabel(""); ax.set_ylabel("Patients")
    _save(fig, "01_class_distribution.png")

    fig, axes = plt.subplots(2, 3, figsize=(14, 8))
    for ax, col in zip(axes.flat, NUMERIC_FEATURES):
        sns.kdeplot(data=d, x=col, hue="Diagnosis", palette=PALETTE, fill=True, common_norm=False,
                    alpha=0.35, ax=ax)
        ax.set_xlabel(feature_label(col)); ax.set_ylabel("Density")
    axes.flat[-1].axis("off")
    fig.suptitle("Distribution of clinical measurements by diagnosis", fontsize=14)
    _save(fig, "02_numeric_distributions.png")

    fig, axes = plt.subplots(1, 4, figsize=(18, 4.5))
    for ax, col in zip(axes, NOMINAL_FEATURES):
        rate = d.groupby(col)[TARGET].mean().mul(100)
        labels = [decode_value(col, v) for v in rate.index]
        ax.bar(labels, rate.values, color=[ORANGE if r > d[TARGET].mean() * 100 else BLUE for r in rate.values])
        ax.axhline(d[TARGET].mean() * 100, ls=":", color="grey")
        ax.set_title(feature_label(col)); ax.set_ylabel("Heart disease rate (%)"); ax.set_ylim(0, 100)
        ax.tick_params(axis="x", rotation=25)
    _save(fig, "03_category_disease_rates.png")

    fig, ax = plt.subplots(figsize=(11, 9))
    cols = [c for c in df.columns if c != TARGET] + [TARGET]
    corr = df[cols].corr()
    sns.heatmap(corr, annot=True, fmt=".2f", cmap="RdBu_r", center=0, square=True, ax=ax,
                xticklabels=[feature_label(c) if c != TARGET else "Heart disease" for c in cols],
                yticklabels=[feature_label(c) if c != TARGET else "Heart disease" for c in cols],
                cbar_kws={"shrink": 0.7})
    ax.set_title("Correlation matrix")
    _save(fig, "04_correlation_heatmap.png")

    fig, ax = plt.subplots(figsize=(7, 5))
    sns.scatterplot(data=d, x="age", y="thalach", hue="Diagnosis", palette=PALETTE, s=45,
                    edgecolor="white", ax=ax)
    ax.set_xlabel("Age (years)"); ax.set_ylabel("Maximum heart rate (bpm)")
    ax.set_title("Maximum heart rate vs age")
    _save(fig, "05_age_vs_max_heart_rate.png")


def model_figures(report: dict) -> None:
    lb = pd.DataFrame(report["leaderboard"]).sort_values("cv_roc_auc_mean")
    fig, ax = plt.subplots(figsize=(8, 4.8))
    ax.barh(lb["model"], lb["cv_roc_auc_mean"], xerr=lb["cv_roc_auc_std"],
            color=[BLUE if m == report["best_model"] else "#b7d3f6" for m in lb["model"]],
            ecolor="grey", capsize=3)
    ax.set_xlim(0.7, 1.0); ax.set_xlabel("Nested-CV ROC-AUC (mean ± sd)")
    ax.set_title("Model comparison")
    _save(fig, "06_model_comparison.png")

    fig, ax = plt.subplots(figsize=(7, 6))
    ax.plot([0, 1], [0, 1], ":", color="grey")
    for i, (name, r) in enumerate(report["test_results"].items()):
        ax.plot(r["roc_curve"]["fpr"], r["roc_curve"]["tpr"], color=SERIES[i],
                lw=3 if name == report["best_model"] else 1.3,
                label=f"{name} ({r['metrics']['roc_auc']:.3f})")
    ax.set_xlabel("False positive rate"); ax.set_ylabel("True positive rate")
    ax.set_title("ROC curves (test set)"); ax.legend(fontsize=8, loc="lower right")
    _save(fig, "07_roc_curves.png")

    best = report["best_model"]
    cm = np.array(report["test_results"][best]["metrics"]["confusion_matrix"])
    fig, ax = plt.subplots(figsize=(5, 4.2))
    sns.heatmap(cm, annot=True, fmt="d", cmap="Blues", cbar=False, ax=ax,
                xticklabels=CLASS_NAMES, yticklabels=CLASS_NAMES, annot_kws={"size": 16})
    ax.set_xlabel("Predicted"); ax.set_ylabel("Actual"); ax.set_title(f"Confusion matrix: {best}")
    _save(fig, "08_confusion_matrix.png")

    perm = pd.DataFrame(report["importance"]["permutation"]).sort_values("mean")
    fig, ax = plt.subplots(figsize=(8, 5.5))
    ax.barh([feature_label(f) for f in perm["feature"]], perm["mean"], xerr=perm["std"],
            color=[BLUE if v > 0 else "#cccccc" for v in perm["mean"]], ecolor="grey", capsize=2)
    ax.axvline(0, color="grey", lw=0.8)
    ax.set_xlabel("Drop in ROC-AUC when shuffled"); ax.set_title("Permutation feature importance")
    _save(fig, "09_feature_importance.png")

    lc = report["learning_curve"]
    fig, ax = plt.subplots(figsize=(7, 4.5))
    for key, label, c in (("train", "Training", BLUE), ("val", "Cross-validation", ORANGE)):
        m, s = np.array(lc[f"{key}_mean"]), np.array(lc[f"{key}_std"])
        ax.plot(lc["train_sizes"], m, "o-", color=c, label=label)
        ax.fill_between(lc["train_sizes"], m - s, m + s, color=c, alpha=0.15)
    ax.set_xlabel("Training patients"); ax.set_ylabel("ROC-AUC"); ax.set_title("Learning curve")
    ax.legend()
    _save(fig, "10_learning_curve.png")


def main() -> None:
    FIGURE_DIR.mkdir(parents=True, exist_ok=True)
    df, _ = load_clean()
    sns.set_theme(style="whitegrid", font_scale=0.95)
    print("Exploratory figures")
    eda_figures(df)
    if REPORT_PATH.exists():
        print("Model figures")
        model_figures(json.loads(REPORT_PATH.read_text()))
    else:
        print("Model report not found; run src/train.py to add model figures.")


if __name__ == "__main__":
    main()
