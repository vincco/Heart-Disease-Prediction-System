"""
charts.py
---------
Plotly figure builders for the GUI. All charts share one visual system:

* a validated categorical palette applied in fixed order (never cycled),
* "No disease" is always blue and "Heart disease" is always orange,
* status colours (green / amber / red) are reserved for risk bands and are
  always paired with a text label,
* thin marks, recessive grid, hover tooltips on every chart.
"""

from __future__ import annotations

import numpy as np
import pandas as pd
import plotly.graph_objects as go

from config import CLASS_NAMES, FEATURE_INFO, TARGET, decode_value, feature_label

# --------------------------------------------------------------------------
# Design tokens
# --------------------------------------------------------------------------
SURFACE = "#fcfcfb"
TEXT = "#0b0b0b"
TEXT_2 = "#52514e"
MUTED = "#8a8984"
GRID = "#e8e7e3"

SERIES = ["#2a78d6", "#eb6834", "#1baf7a", "#eda100",
          "#e87ba4", "#008300", "#6250d6", "#e34948"]
HEALTHY_C, DISEASE_C = SERIES[0], SERIES[1]
CLASS_COLORS = {0: HEALTHY_C, 1: DISEASE_C}

STATUS = {"good": "#0ca30c", "warning": "#fab219", "critical": "#d03b3b"}
SEQ_BLUE = ["#f0efec", "#cde2fb", "#9ec5f4", "#6da7ec", "#3987e5", "#256abf", "#184f95", "#0d366b"]
DIVERGING = [[0.0, "#1c5cab"], [0.25, "#86b6ef"], [0.5, "#f0efec"],
             [0.75, "#f0a080"], [1.0, "#c0392b"]]

FONT = "Inter, -apple-system, Segoe UI, Roboto, sans-serif"


def _base(fig: go.Figure, title: str | None = None, height: int = 380,
          legend: bool = True) -> go.Figure:
    fig.update_layout(
        title=dict(text=title, x=0, xanchor="left", font=dict(size=15, color=TEXT)) if title else None,
        height=height,
        margin=dict(l=10, r=10, t=50 if title else 20, b=10),
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor=SURFACE,
        font=dict(family=FONT, size=12, color=TEXT_2),
        hoverlabel=dict(bgcolor="white", bordercolor=GRID, font=dict(family=FONT, color=TEXT)),
        showlegend=legend,
        legend=dict(orientation="h", yanchor="bottom", y=1.0, xanchor="right", x=1,
                    bgcolor="rgba(0,0,0,0)", font=dict(color=TEXT_2)),
        bargap=0.25,
    )
    fig.update_xaxes(gridcolor=GRID, zeroline=False, linecolor=GRID, ticks="",
                     title_font=dict(color=TEXT_2))
    fig.update_yaxes(gridcolor=GRID, zeroline=False, linecolor=GRID, ticks="",
                     title_font=dict(color=TEXT_2))
    return fig


# --------------------------------------------------------------------------
# Exploratory charts
# --------------------------------------------------------------------------
def class_balance_donut(df: pd.DataFrame) -> go.Figure:
    counts = df[TARGET].value_counts().sort_index()
    fig = go.Figure(go.Pie(
        labels=[CLASS_NAMES[i] for i in counts.index], values=counts.values,
        hole=0.62, sort=False, direction="clockwise",
        marker=dict(colors=[CLASS_COLORS[i] for i in counts.index],
                    line=dict(color="white", width=2)),
        textinfo="percent", textfont=dict(color="white", size=13),
        hovertemplate="%{label}<br>%{value} patients (%{percent})<extra></extra>",
    ))
    fig.add_annotation(text=f"<b>{len(df)}</b><br>patients", showarrow=False,
                       font=dict(size=16, color=TEXT))
    return _base(fig, "Diagnosis split", height=320)


def numeric_distribution(df: pd.DataFrame, col: str) -> go.Figure:
    info = FEATURE_INFO[col]
    fig = go.Figure()
    for cls in (0, 1):
        vals = df.loc[df[TARGET] == cls, col].dropna()
        fig.add_trace(go.Histogram(
            x=vals, name=CLASS_NAMES[cls], marker_color=CLASS_COLORS[cls],
            opacity=0.75, nbinsx=20,
            marker_line=dict(color="white", width=1),
            hovertemplate=f"{info['label']}: %{{x}}<br>Patients: %{{y}}<extra>{CLASS_NAMES[cls]}</extra>",
        ))
    if "healthy" in info:
        lo, hi = info["healthy"]
        fig.add_vrect(x0=lo, x1=hi, fillcolor=STATUS["good"], opacity=0.07, line_width=0,
                      annotation_text="Healthy range", annotation_position="top left",
                      annotation_font=dict(color=TEXT_2, size=11))
    fig.update_layout(barmode="overlay")
    fig.update_xaxes(title=f"{info['label']} ({info.get('unit', '')})")
    fig.update_yaxes(title="Patients")
    return _base(fig, f"{info['label']} by diagnosis")


def numeric_box(df: pd.DataFrame, col: str) -> go.Figure:
    info = FEATURE_INFO[col]
    fig = go.Figure()
    for cls in (0, 1):
        fig.add_trace(go.Box(
            y=df.loc[df[TARGET] == cls, col], name=CLASS_NAMES[cls],
            marker_color=CLASS_COLORS[cls], boxmean=True, line=dict(width=2),
            boxpoints="outliers",
        ))
    fig.update_yaxes(title=f"{info['label']} ({info.get('unit', '')})")
    return _base(fig, "Spread and outliers", legend=False)


def category_disease_rate(df: pd.DataFrame, col: str) -> go.Figure:
    info = FEATURE_INFO[col]
    g = df.groupby(col)[TARGET].agg(["mean", "count"]).reset_index()
    g["label"] = g[col].apply(lambda v: decode_value(col, v))
    overall = df[TARGET].mean()
    fig = go.Figure(go.Bar(
        x=g["label"], y=g["mean"] * 100,
        marker=dict(color=[DISEASE_C if m > overall else HEALTHY_C for m in g["mean"]],
                    cornerradius=4),
        text=[f"{m*100:.0f}%" for m in g["mean"]], textposition="outside",
        textfont=dict(color=TEXT),
        customdata=g["count"],
        hovertemplate="%{x}<br>Disease rate: %{y:.1f}%<br>Patients: %{customdata}<extra></extra>",
    ))
    fig.add_hline(y=overall * 100, line=dict(color=MUTED, dash="dot", width=1.5),
                  annotation_text=f"Overall {overall*100:.0f}%",
                  annotation_position="top right", annotation_font=dict(color=TEXT_2))
    fig.update_yaxes(title="Heart disease rate (%)", range=[0, 105])
    fig.update_xaxes(title=info["label"])
    return _base(fig, f"Heart disease rate by {info['label'].lower()}", legend=False)


def correlation_heatmap(df: pd.DataFrame) -> go.Figure:
    cols = [c for c in df.columns if c in FEATURE_INFO] + [TARGET]
    corr = df[cols].corr()
    labels = [feature_label(c) if c != TARGET else "HEART DISEASE" for c in cols]
    fig = go.Figure(go.Heatmap(
        z=corr.values, x=labels, y=labels, zmin=-1, zmax=1, colorscale=DIVERGING,
        text=np.round(corr.values, 2), texttemplate="%{text}", textfont=dict(size=9),
        hovertemplate="%{y} vs %{x}<br>r = %{z:.2f}<extra></extra>",
        colorbar=dict(title="r", thickness=10),
        xgap=2, ygap=2,
    ))
    fig.update_yaxes(autorange="reversed", gridcolor="rgba(0,0,0,0)")
    fig.update_xaxes(tickangle=-40, gridcolor="rgba(0,0,0,0)")
    return _base(fig, "Correlation matrix (Pearson r)", height=620, legend=False)


def target_correlation_bars(df: pd.DataFrame) -> go.Figure:
    # Nominal codes (chest pain, ECG, slope, thallium) have no natural order, so a
    # Pearson correlation on them is not meaningful; they are analysed per category instead.
    cols = [c for c in df.columns if c in FEATURE_INFO and FEATURE_INFO[c]["kind"] != "nominal"]
    corr = df[cols + [TARGET]].corr()[TARGET].drop(TARGET)
    corr = corr.reindex(corr.abs().sort_values().index)
    fig = go.Figure(go.Bar(
        x=corr.values, y=[feature_label(c) for c in corr.index], orientation="h",
        marker=dict(color=[DISEASE_C if v > 0 else HEALTHY_C for v in corr.values], cornerradius=4),
        hovertemplate="%{y}<br>r = %{x:.2f}<extra></extra>",
    ))
    fig.add_vline(x=0, line=dict(color=MUTED, width=1))
    fig.update_xaxes(title="Correlation with heart disease (orange = higher in disease, blue = lower)")
    return _base(fig, "Which measurements move with heart disease?", height=380, legend=False)


def scatter_two(df: pd.DataFrame, x: str, y: str) -> go.Figure:
    fig = go.Figure()
    for cls in (0, 1):
        d = df[df[TARGET] == cls]
        fig.add_trace(go.Scatter(
            x=d[x], y=d[y], mode="markers", name=CLASS_NAMES[cls],
            marker=dict(color=CLASS_COLORS[cls], size=9, opacity=0.8,
                        line=dict(color="white", width=1.5)),
            hovertemplate=(f"{feature_label(x)}: %{{x}}<br>{feature_label(y)}: %{{y}}"
                           f"<extra>{CLASS_NAMES[cls]}</extra>"),
        ))
    fig.update_xaxes(title=feature_label(x))
    fig.update_yaxes(title=feature_label(y))
    return _base(fig, f"{feature_label(y)} vs {feature_label(x)}", height=430)


def age_band_rate(df: pd.DataFrame) -> go.Figure:
    bands = pd.cut(df["age"], [0, 40, 50, 60, 70, 120], labels=["<40", "40-49", "50-59", "60-69", "70+"])
    g = df.groupby([bands, "sex"], observed=True)[TARGET].agg(["mean", "count"]).reset_index()
    fig = go.Figure()
    for sex, color in ((0, SERIES[2]), (1, SERIES[6])):
        d = g[g["sex"] == sex]
        name = decode_value("sex", sex)
        fig.add_trace(go.Bar(
            x=d["age"].astype(str), y=d["mean"] * 100, name=name,
            marker=dict(color=color, cornerradius=4), customdata=d["count"],
            hovertemplate=f"{name}, age %{{x}}<br>Disease rate %{{y:.0f}}%<br>Patients %{{customdata}}<extra></extra>",
        ))
    fig.update_layout(barmode="group", bargroupgap=0.08)
    fig.update_yaxes(title="Heart disease rate (%)", range=[0, 100])
    fig.update_xaxes(title="Age band")
    return _base(fig, "Disease rate by age band and sex")


# --------------------------------------------------------------------------
# Model evaluation charts
# --------------------------------------------------------------------------
def leaderboard_bars(lb: pd.DataFrame, metric: str, best: str) -> go.Figure:
    lb = lb.sort_values(f"cv_{metric}_mean")
    colors = [SERIES[0] if m == best else "#b7d3f6" for m in lb["model"]]
    fig = go.Figure(go.Bar(
        x=lb[f"cv_{metric}_mean"], y=lb["model"], orientation="h",
        error_x=dict(type="data", array=lb[f"cv_{metric}_std"], color=MUTED, thickness=1.2),
        marker=dict(color=colors, cornerradius=4),
        text=[f"{v:.3f}" for v in lb[f"cv_{metric}_mean"]], textposition="inside",
        insidetextanchor="start", textfont=dict(color=[("white" if m == best else TEXT) for m in lb["model"]]),
        hovertemplate="%{y}<br>mean %{x:.3f}<extra></extra>",
    ))
    lo = max(0.0, lb[f"cv_{metric}_mean"].min() - 0.15)
    fig.update_xaxes(range=[lo, 1.0], title=f"Nested-CV {metric.replace('_', '-').upper()} (mean +/- 1 sd)")
    return _base(fig, None, height=360, legend=False)


def roc_curves(test_results: dict, y_test, highlight: str) -> go.Figure:
    fig = go.Figure()
    fig.add_trace(go.Scatter(x=[0, 1], y=[0, 1], mode="lines", name="Random guess",
                             line=dict(color=MUTED, dash="dot", width=1), hoverinfo="skip"))
    for i, (name, res) in enumerate(test_results.items()):
        auc = res["metrics"]["roc_auc"]
        is_best = name == highlight
        fig.add_trace(go.Scatter(
            x=res["roc_curve"]["fpr"], y=res["roc_curve"]["tpr"], mode="lines",
            name=f"{name} ({auc:.3f})",
            line=dict(color=SERIES[i % len(SERIES)], width=3.5 if is_best else 1.6, shape="hv"),
            opacity=1 if is_best else 0.55,
            hovertemplate="FPR %{x:.2f}<br>TPR %{y:.2f}<extra>" + name + "</extra>",
        ))
    fig.update_xaxes(title="False positive rate (1 - specificity)", range=[-0.01, 1.01])
    fig.update_yaxes(title="True positive rate (recall)", range=[-0.01, 1.01])
    fig = _base(fig, "ROC curves on the held-out test set (AUC in brackets)", height=500)
    fig.update_layout(legend=dict(orientation="v", x=0.99, xanchor="right", y=0.02, yanchor="bottom",
                                  bgcolor="rgba(255,255,255,0.85)", font=dict(size=11)))
    return fig


def pr_curves(test_results: dict, highlight: str, base_rate: float) -> go.Figure:
    fig = go.Figure()
    fig.add_hline(y=base_rate, line=dict(color=MUTED, dash="dot", width=1),
                  annotation_text="Random guess", annotation_font=dict(color=TEXT_2))
    for i, (name, res) in enumerate(test_results.items()):
        is_best = name == highlight
        fig.add_trace(go.Scatter(
            x=res["pr_curve"]["recall"], y=res["pr_curve"]["precision"], mode="lines",
            name=f"{name} ({res['metrics']['pr_auc']:.3f})",
            line=dict(color=SERIES[i % len(SERIES)], width=3.5 if is_best else 1.6, shape="hv"),
            opacity=1 if is_best else 0.55,
            hovertemplate="Recall %{x:.2f}<br>Precision %{y:.2f}<extra>" + name + "</extra>",
        ))
    fig.update_xaxes(title="Recall", range=[-0.01, 1.01])
    fig.update_yaxes(title="Precision", range=[0, 1.03])
    fig = _base(fig, "Precision-recall curves (average precision in brackets)", height=500)
    fig.update_layout(legend=dict(orientation="v", x=0.01, xanchor="left", y=0.02, yanchor="bottom",
                                  bgcolor="rgba(255,255,255,0.85)", font=dict(size=11)))
    return fig


def confusion_matrix_fig(cm: list[list[int]]) -> go.Figure:
    cm = np.array(cm)
    total = cm.sum()
    names = [["True negative", "False positive"], ["False negative", "True positive"]]
    text = [[f"<b>{cm[i, j]}</b><br>{names[i][j]}<br>{cm[i, j] / total * 100:.0f}%" for j in range(2)]
            for i in range(2)]
    fig = go.Figure(go.Heatmap(
        z=cm, x=[f"Predicted: {c}" for c in CLASS_NAMES], y=[f"Actual: {c}" for c in CLASS_NAMES],
        colorscale=[[0, "#eef4fc"], [1, "#256abf"]], showscale=False,
        text=text, texttemplate="%{text}", textfont=dict(size=14),
        hovertemplate="%{y}<br>%{x}<br>%{z} patients<extra></extra>", xgap=3, ygap=3,
    ))
    fig.update_yaxes(autorange="reversed", gridcolor="rgba(0,0,0,0)")
    fig.update_xaxes(side="top", gridcolor="rgba(0,0,0,0)")
    return _base(fig, None, height=340, legend=False)


def threshold_sweep(y_true, proba, current: float) -> go.Figure:
    y_true = np.asarray(y_true)
    proba = np.asarray(proba)
    thr = np.linspace(0.05, 0.95, 91)
    rows = []
    for t in thr:
        p = (proba >= t).astype(int)
        tp = ((p == 1) & (y_true == 1)).sum()
        fp = ((p == 1) & (y_true == 0)).sum()
        fn = ((p == 0) & (y_true == 1)).sum()
        tn = ((p == 0) & (y_true == 0)).sum()
        prec = tp / (tp + fp) if tp + fp else 1.0
        rec = tp / (tp + fn) if tp + fn else 0.0
        rows.append({"t": t, "Recall (sensitivity)": rec, "Precision": prec,
                     "Specificity": tn / (tn + fp) if tn + fp else 0.0,
                     "Accuracy": (tp + tn) / len(y_true)})
    d = pd.DataFrame(rows)
    fig = go.Figure()
    for i, col in enumerate(["Recall (sensitivity)", "Precision", "Specificity", "Accuracy"]):
        fig.add_trace(go.Scatter(x=d["t"], y=d[col], name=col, mode="lines",
                                 line=dict(color=SERIES[[1, 0, 2, 6][i]], width=2),
                                 hovertemplate=f"{col}: %{{y:.2f}}<extra></extra>"))
    fig.add_vline(x=current, line=dict(color=TEXT, width=1.5, dash="dash"),
                  annotation_text=f"threshold {current:.2f}", annotation_font=dict(color=TEXT))
    fig.update_layout(hovermode="x unified")
    fig.update_xaxes(title="Decision threshold (probability needed to flag disease)")
    fig.update_yaxes(title="Score", range=[0, 1.03])
    return _base(fig, "How the decision threshold trades sensitivity for specificity", height=400)


def permutation_importance_fig(imp: dict) -> go.Figure:
    d = pd.DataFrame(imp).sort_values("mean")
    fig = go.Figure(go.Bar(
        x=d["mean"], y=[feature_label(f) for f in d["feature"]], orientation="h",
        error_x=dict(type="data", array=d["std"], color=MUTED, thickness=1.2),
        marker=dict(color=[SERIES[0] if v > 0 else "#cfcfca" for v in d["mean"]], cornerradius=4),
        hovertemplate="%{y}<br>ROC-AUC drop when shuffled: %{x:.3f}<extra></extra>",
    ))
    fig.add_vline(x=0, line=dict(color=MUTED, width=1))
    fig.update_xaxes(title="Drop in ROC-AUC when shuffled")
    return _base(fig, "Permutation feature importance (test set, 30 shuffles)", height=470, legend=False)


def learning_curve_fig(lc: dict) -> go.Figure:
    x = lc["train_sizes"]
    fig = go.Figure()
    for key, name, color in (("train", "Training score", SERIES[0]),
                             ("val", "Cross-validation score", SERIES[1])):
        m = np.array(lc[f"{key}_mean"])
        s = np.array(lc[f"{key}_std"])
        fig.add_trace(go.Scatter(x=list(x) + list(x)[::-1], y=list(m + s) + list(m - s)[::-1],
                                 fill="toself", fillcolor=color, opacity=0.12, line=dict(width=0),
                                 hoverinfo="skip", showlegend=False))
        fig.add_trace(go.Scatter(x=x, y=m, name=name, mode="lines+markers",
                                 line=dict(color=color, width=2), marker=dict(size=8),
                                 hovertemplate=f"{name}<br>%{{x}} patients: %{{y:.3f}}<extra></extra>"))
    fig.update_xaxes(title="Number of training patients")
    fig.update_yaxes(title="ROC-AUC")
    return _base(fig, "Learning curve", height=380)


def calibration_fig(cal: dict) -> go.Figure:
    fig = go.Figure()
    fig.add_trace(go.Scatter(x=[0, 1], y=[0, 1], mode="lines", name="Perfect calibration",
                             line=dict(color=MUTED, dash="dot", width=1), hoverinfo="skip"))
    fig.add_trace(go.Scatter(
        x=cal["mean_predicted"], y=cal["fraction_positive"], mode="lines+markers", name="Model",
        line=dict(color=SERIES[0], width=2), marker=dict(size=9, line=dict(color="white", width=1.5)),
        hovertemplate="Predicted %{x:.2f}<br>Observed %{y:.2f}<extra></extra>",
    ))
    fig.update_xaxes(title="Mean predicted probability", range=[0, 1])
    fig.update_yaxes(title="Observed fraction with disease", range=[0, 1])
    return _base(fig, "Reliability diagram (out-of-fold, training set)", height=380)


# --------------------------------------------------------------------------
# Clustering charts
# --------------------------------------------------------------------------
def silhouette_fig(k_scores: list[dict], best_k: int) -> go.Figure:
    d = pd.DataFrame(k_scores)
    fig = go.Figure(go.Bar(
        x=d["k"].astype(str), y=d["silhouette"],
        marker=dict(color=[SERIES[0] if k == best_k else "#b7d3f6" for k in d["k"]], cornerradius=4),
        text=[f"{v:.3f}" for v in d["silhouette"]], textposition="outside", textfont=dict(color=TEXT),
        hovertemplate="k = %{x}<br>silhouette %{y:.3f}<extra></extra>",
    ))
    fig.update_xaxes(title="Number of clusters (k)")
    fig.update_yaxes(title="Silhouette score")
    return _base(fig, "Choosing k", height=330, legend=False)


def elbow_fig(k_scores: list[dict], best_k: int) -> go.Figure:
    d = pd.DataFrame(k_scores)
    fig = go.Figure(go.Scatter(
        x=d["k"], y=d["inertia"], mode="lines+markers",
        line=dict(color=SERIES[0], width=2), marker=dict(size=9),
        hovertemplate="k = %{x}<br>inertia %{y:.0f}<extra></extra>",
    ))
    fig.add_vline(x=best_k, line=dict(color=MUTED, dash="dot"))
    fig.update_xaxes(title="Number of clusters (k)", dtick=1)
    fig.update_yaxes(title="Within-cluster sum of squares")
    return _base(fig, "Elbow method", height=330, legend=False)


def cluster_scatter(coords, labels, y, names: dict, evr) -> go.Figure:
    coords = np.asarray(coords)
    labels = np.asarray(labels)
    y = np.asarray(y)
    fig = go.Figure()
    for c in sorted(set(labels)):
        m = labels == c
        fig.add_trace(go.Scatter(
            x=coords[m, 0], y=coords[m, 1], mode="markers", name=names.get(c, f"Segment {c+1}"),
            marker=dict(color=SERIES[[2, 6, 3, 4, 7, 5][c]], size=9, opacity=0.85,
                        symbol=["circle" if v == 0 else "diamond" for v in y[m]],
                        line=dict(color="white", width=1.2)),
            text=[CLASS_NAMES[v] for v in y[m]],
            hovertemplate="%{text}<extra>" + names.get(c, f"Segment {c+1}") + "</extra>",
        ))
    fig.update_xaxes(title=f"Principal component 1 ({evr[0]*100:.0f}% of variance)")
    fig.update_yaxes(title=f"Principal component 2 ({evr[1]*100:.0f}% of variance)")
    return _base(fig, "Patient segments projected to 2-D (circle = no disease, diamond = disease)", height=470)


# --------------------------------------------------------------------------
# Prediction charts
# --------------------------------------------------------------------------
def risk_band(prob: float) -> tuple[str, str]:
    if prob < 0.30:
        return "Low risk", STATUS["good"]
    if prob < 0.60:
        return "Moderate risk", STATUS["warning"]
    return "High risk", STATUS["critical"]


def risk_gauge(prob: float, threshold: float) -> go.Figure:
    label, color = risk_band(prob)
    fig = go.Figure(go.Indicator(
        mode="gauge+number", value=prob * 100,
        number=dict(suffix="%", font=dict(size=44, color=TEXT)),
        gauge=dict(
            axis=dict(range=[0, 100], tickwidth=1, tickcolor=GRID, ticksuffix="%"),
            bar=dict(color=color, thickness=0.28),
            bgcolor="white", borderwidth=0,
            steps=[dict(range=[0, 30], color="#e6f4e6"),
                   dict(range=[30, 60], color="#fdf1d6"),
                   dict(range=[60, 100], color="#f8e0e0")],
            threshold=dict(line=dict(color=TEXT, width=3), thickness=0.85, value=threshold * 100),
        ),
        title=dict(text=f"<b>{label}</b><br><span style='font-size:12px;color:{TEXT_2}'>"
                        f"estimated probability of heart disease</span>",
                   font=dict(size=18, color=color)),
    ))
    fig.update_layout(height=300, margin=dict(l=40, r=45, t=80, b=10),
                      paper_bgcolor="rgba(0,0,0,0)", font=dict(family=FONT))
    return fig


def contribution_fig(contrib: pd.DataFrame) -> go.Figure:
    d = contrib[contrib["impact"].abs() > 1e-3].sort_values("impact", key=np.abs).tail(10)
    fig = go.Figure(go.Bar(
        x=d["impact"], y=d["label"], orientation="h",
        marker=dict(color=[DISEASE_C if v > 0 else HEALTHY_C for v in d["impact"]], cornerradius=4),
        customdata=np.stack([d["value_text"], d["reference_text"], d["delta"] * 100], axis=1),
        hovertemplate=("%{y}<br>This patient: %{customdata[0]}<br>Typical patient: %{customdata[1]}"
                       "<br>Influence (log-odds): %{x:+.2f}"
                       "<br>Risk change: %{customdata[2]:+.1f} percentage points<extra></extra>"),
    ))
    fig.add_vline(x=0, line=dict(color=MUTED, width=1))
    lim = max(float(d["impact"].abs().max()) if len(d) else 1.0, 0.5) * 1.15
    fig.update_xaxes(range=[-lim, lim],
                     title="Influence vs a typical patient (log-odds)")
    return _base(fig, "What drives this prediction", height=420, legend=False)


def percentile_fig(df: pd.DataFrame, patient: dict) -> go.Figure:
    cols = ["age", "trestbps", "chol", "thalach", "oldpeak"]
    pct = [float((df[c] < patient[c]).mean() * 100) for c in cols]
    labels = [feature_label(c) for c in cols]
    fig = go.Figure()
    fig.add_trace(go.Bar(x=[100] * len(cols), y=labels, orientation="h", marker_color="#efeeea",
                         hoverinfo="skip", showlegend=False))
    fig.add_trace(go.Scatter(
        x=pct, y=labels, mode="markers+text", marker=dict(size=16, color=SERIES[6],
                                                          line=dict(color="white", width=2)),
        text=[f"{p:.0f}th" for p in pct], textposition="middle right",
        textfont=dict(color=TEXT), showlegend=False,
        customdata=[patient[c] for c in cols],
        hovertemplate="%{y}: %{customdata}<br>Higher than %{x:.0f}% of patients<extra></extra>",
    ))
    fig.update_layout(barmode="overlay")
    fig.update_xaxes(range=[0, 108], title="Percentile within the 302 study patients")
    return _base(fig, "How this patient compares with the study population", height=300, legend=False)
