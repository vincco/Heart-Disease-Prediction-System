"""
api.py
------
REST endpoint for the trained model (the "served endpoint" stage of the ML lifecycle).

Run:
    uvicorn src.api:app --reload
Then open http://127.0.0.1:8000/docs for interactive documentation.
"""

from __future__ import annotations

import sys
from pathlib import Path

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field

sys.path.append(str(Path(__file__).resolve().parent))
from predict import ModelNotTrainedError, explain_one, load_artifacts, predict_one  # noqa: E402

app = FastAPI(title="Heart Disease Prediction API", version="1.0.0",
              description="Educational model. Not for clinical use.")


class Patient(BaseModel):
    age: float = Field(..., ge=18, le=100, examples=[63])
    sex: int = Field(..., ge=0, le=1, description="0 = female, 1 = male", examples=[1])
    cp: int = Field(..., ge=0, le=3, description="0 asymptomatic, 1 atypical, 2 non-anginal, 3 typical",
                    examples=[0])
    trestbps: float = Field(..., ge=80, le=220, examples=[145])
    chol: float = Field(..., ge=100, le=600, examples=[233])
    fbs: int = Field(..., ge=0, le=1, examples=[1])
    restecg: int = Field(..., ge=0, le=2, description="0 LV hypertrophy, 1 normal, 2 ST-T abnormality",
                         examples=[0])
    thalach: float = Field(..., ge=60, le=220, examples=[150])
    exang: int = Field(..., ge=0, le=1, examples=[0])
    oldpeak: float = Field(..., ge=0, le=7, examples=[2.3])
    slope: int = Field(..., ge=0, le=2, description="0 downsloping, 1 flat, 2 upsloping", examples=[0])
    ca: int = Field(..., ge=0, le=3, examples=[0])
    thal: int = Field(..., ge=1, le=3, description="1 fixed defect, 2 normal, 3 reversible defect",
                      examples=[1])


@app.get("/health")
def health() -> dict:
    try:
        bundle = load_artifacts()
        return {"status": "ok", "model": bundle["model_name"], "threshold": bundle["threshold"]}
    except ModelNotTrainedError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc


@app.post("/predict")
def predict(patient: Patient, explain: bool = False) -> dict:
    try:
        result = predict_one(patient.model_dump())
        if explain:
            contrib = explain_one(patient.model_dump())
            result["contributions"] = (contrib[["feature", "delta", "impact"]]
                                       .sort_values("impact", key=abs, ascending=False)
                                       .to_dict(orient="records"))
        return result
    except ModelNotTrainedError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
