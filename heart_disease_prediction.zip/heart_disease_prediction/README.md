# Heart Disease Prediction System

A machine learning project that predicts a patient's likelihood of heart
disease from clinical measurements, using the classic UCI Cleveland Heart
Disease dataset (303 patients, 13 features).

## Project Structure

```
heart_disease_prediction/
├── data/
│   └── heart.csv              # UCI heart disease dataset
├── model/                      # created after training
│   ├── heart_disease_model.pkl
│   ├── scaler.pkl
│   ├── model_name.pkl
│   └── *.png                   # EDA plots
├── src/
│   ├── preprocess.py           # data loading, cleaning, scaling
│   ├── train.py                # trains & compares 5 models, saves the best
│   ├── predict.py              # loads saved model, predicts on new patients
│   └── eda.py                  # generates exploratory data analysis plots
├── requirements.txt
└── README.md
```

## Setup

```bash
pip install -r requirements.txt
```

## Usage

### 1. Explore the data (optional)
```bash
python src/eda.py
```
Generates `target_distribution.png`, `correlation_heatmap.png`, and
`age_distribution.png` in `model/`.

### 2. Train the models
```bash
python src/train.py
```
Trains and compares 5 classifiers — Logistic Regression, Decision Tree,
Random Forest, SVM (RBF kernel), and K-Nearest Neighbors — on an 80/20
train/test split, prints accuracy/precision/recall/F1/ROC-AUC for each, and
saves the best-performing model + scaler to `model/`.

Typical results on this dataset:

| Model | Accuracy | Precision | Recall | F1 | ROC-AUC |
|---|---|---|---|---|---|
| SVM (RBF) | 0.84 | 0.79 | 0.94 | 0.86 | 0.88 |
| Decision Tree | 0.82 | 0.75 | 1.00 | 0.86 | 0.82 |
| K-Nearest Neighbors | 0.82 | 0.79 | 0.91 | 0.85 | 0.89 |
| Random Forest | 0.80 | 0.76 | 0.94 | 0.84 | 0.88 |
| Logistic Regression | 0.79 | 0.76 | 0.88 | 0.82 | 0.86 |

### 3. Predict for a new patient
```bash
python src/predict.py
```
Prompts you interactively for the 13 clinical values and prints the
predicted risk and probability.

You can also call it programmatically:
```python
from src.predict import predict_one

patient = {
    "age": 63, "sex": 1, "cp": 3, "trestbps": 145, "chol": 233,
    "fbs": 1, "restecg": 0, "thalach": 150, "exang": 0,
    "oldpeak": 2.3, "slope": 0, "ca": 0, "thal": 1,
}
prediction, probability = predict_one(patient)
print(prediction, probability)
```

## Dataset Features

| Column | Description |
|---|---|
| age | Age in years |
| sex | 1 = male, 0 = female |
| cp | Chest pain type (0–3) |
| trestbps | Resting blood pressure (mm Hg) |
| chol | Serum cholesterol (mg/dl) |
| fbs | Fasting blood sugar > 120 mg/dl (1/0) |
| restecg | Resting ECG results (0–2) |
| thalach | Max heart rate achieved |
| exang | Exercise-induced angina (1/0) |
| oldpeak | ST depression from exercise |
| slope | Slope of peak exercise ST segment (0–2) |
| ca | Major vessels colored by fluoroscopy (0–4) |
| thal | Thalassemia (0–3) |
| target | 1 = heart disease present, 0 = absent |

## Notes

- This project is for **educational purposes only** and is not a substitute
  for professional medical diagnosis.
- The dataset is small (303 rows), so results should be interpreted with
  that limitation in mind. For production use, retrain on a larger,
  more representative dataset and validate carefully.
