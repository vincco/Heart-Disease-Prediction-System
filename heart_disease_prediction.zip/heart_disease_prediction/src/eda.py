"""
eda.py
------
Generates exploratory data analysis plots for the heart disease dataset:
- Target class distribution
- Correlation heatmap
- Age distribution by disease status

Saves plots as PNG files into the 'model/' (output) folder.

Run:
    python src/eda.py
"""

import os
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns

from preprocess import load_data, clean_data

DATA_PATH = os.path.join(os.path.dirname(__file__), "..", "data", "heart.csv")
OUTPUT_DIR = os.path.join(os.path.dirname(__file__), "..", "model")


def main():
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    df = clean_data(load_data(DATA_PATH))

    sns.set_theme(style="whitegrid")

    # 1. Target distribution
    plt.figure(figsize=(5, 4))
    sns.countplot(x="target", data=df, hue="target", palette="Set2", legend=False)
    plt.title("Heart Disease Class Distribution")
    plt.xlabel("Target (0 = No Disease, 1 = Disease)")
    plt.ylabel("Count")
    plt.tight_layout()
    plt.savefig(os.path.join(OUTPUT_DIR, "target_distribution.png"), dpi=150)
    plt.close()

    # 2. Correlation heatmap
    plt.figure(figsize=(10, 8))
    corr = df.corr(numeric_only=True)
    sns.heatmap(corr, annot=True, fmt=".2f", cmap="coolwarm", square=True)
    plt.title("Feature Correlation Heatmap")
    plt.tight_layout()
    plt.savefig(os.path.join(OUTPUT_DIR, "correlation_heatmap.png"), dpi=150)
    plt.close()

    # 3. Age distribution by disease status
    plt.figure(figsize=(6, 4))
    sns.histplot(data=df, x="age", hue="target", multiple="stack", palette="Set2", bins=20)
    plt.title("Age Distribution by Heart Disease Status")
    plt.xlabel("Age")
    plt.tight_layout()
    plt.savefig(os.path.join(OUTPUT_DIR, "age_distribution.png"), dpi=150)
    plt.close()

    print(f"Saved EDA plots to '{OUTPUT_DIR}/'")


if __name__ == "__main__":
    main()
