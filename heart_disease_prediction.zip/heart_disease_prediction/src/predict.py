"""
predict.py
----------
Loads the trained model and scaler, then predicts heart disease
risk for a new patient — either via command-line interactive input
or by passing a dict of feature values programmatically.

Run interactively:
    python src/predict.py
"""

import os
import joblib
import pandas as pd

MODEL_DIR = os.path.join(os.path.dirname(__file__), "..", "model")

FEATURE_INFO = [
    ("age", "Age (years)", float),
    ("sex", "Sex (1 = male, 0 = female)", int),
    ("cp", "Chest pain type (0=typical angina, 1=atypical, 2=non-anginal, 3=asymptomatic)", int),
    ("trestbps", "Resting blood pressure (mm Hg)", float),
    ("chol", "Serum cholesterol (mg/dl)", float),
    ("fbs", "Fasting blood sugar > 120 mg/dl (1 = yes, 0 = no)", int),
    ("restecg", "Resting ECG results (0=normal, 1=ST-T abnormality, 2=LV hypertrophy)", int),
    ("thalach", "Maximum heart rate achieved", float),
    ("exang", "Exercise induced angina (1 = yes, 0 = no)", int),
    ("oldpeak", "ST depression induced by exercise", float),
    ("slope", "Slope of peak exercise ST segment (0-2)", int),
    ("ca", "Number of major vessels colored by fluoroscopy (0-4)", int),
    ("thal", "Thalassemia (0=normal, 1=fixed defect, 2=reversible defect)", int),
]


def load_artifacts():
    model_path = os.path.join(MODEL_DIR, "heart_disease_model.pkl")
    scaler_path = os.path.join(MODEL_DIR, "scaler.pkl")

    if not (os.path.exists(model_path) and os.path.exists(scaler_path)):
        raise FileNotFoundError(
            "Trained model not found. Run 'python src/train.py' first."
        )

    model = joblib.load(model_path)
    scaler = joblib.load(scaler_path)
    return model, scaler


def predict_one(patient: dict, model=None, scaler=None):
    """
    Predict heart disease for a single patient.
    `patient` should be a dict with keys matching FEATURE_INFO names.
    Returns (prediction, probability).
    """
    if model is None or scaler is None:
        model, scaler = load_artifacts()

    columns = [key for key, _, _ in FEATURE_INFO]
    X = pd.DataFrame([[patient[key] for key in columns]], columns=columns)
    X_scaled = scaler.transform(X)

    prediction = model.predict(X_scaled)[0]
    probability = (
        model.predict_proba(X_scaled)[0][1] if hasattr(model, "predict_proba") else None
    )
    return prediction, probability


def interactive_predict():
    print("=" * 55)
    print(" Heart Disease Risk Prediction")
    print("=" * 55)
    print("Enter patient details below:\n")

    patient = {}
    for key, prompt, cast in FEATURE_INFO:
        while True:
            raw = input(f"{prompt}: ").strip()
            try:
                patient[key] = cast(raw)
                break
            except ValueError:
                print(f"  Invalid input, expected a {cast.__name__}. Try again.")

    model, scaler = load_artifacts()
    prediction, probability = predict_one(patient, model, scaler)

    print("\n" + "=" * 55)
    if prediction == 1:
        print(f" RESULT: Higher likelihood of heart disease")
    else:
        print(f" RESULT: Lower likelihood of heart disease")
    if probability is not None:
        print(f" Estimated probability of heart disease: {probability * 100:.1f}%")
    print("=" * 55)
    print("\nNote: This is a machine learning estimate for educational")
    print("purposes only, not a medical diagnosis. Consult a doctor.")


if __name__ == "__main__":
    interactive_predict()
