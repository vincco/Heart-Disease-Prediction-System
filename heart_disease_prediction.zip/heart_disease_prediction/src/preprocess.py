"""
preprocess.py
--------------
Loads the heart disease dataset and prepares it for training:
- Handles missing values (none expected in this cleaned dataset, but checked anyway)
- Splits into features (X) and target (y)
- Scales numerical features
- Splits into train/test sets

Dataset columns:
    age       : age in years
    sex       : 1 = male, 0 = female
    cp        : chest pain type (0-3)
    trestbps  : resting blood pressure (mm Hg)
    chol      : serum cholesterol (mg/dl)
    fbs       : fasting blood sugar > 120 mg/dl (1 = true, 0 = false)
    restecg   : resting electrocardiographic results (0-2)
    thalach   : maximum heart rate achieved
    exang     : exercise induced angina (1 = yes, 0 = no)
    oldpeak   : ST depression induced by exercise relative to rest
    slope     : slope of the peak exercise ST segment (0-2)
    ca        : number of major vessels colored by fluoroscopy (0-4)
    thal      : thalassemia (0-3)
    target    : 1 = has heart disease, 0 = no heart disease
"""

import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler

FEATURE_COLUMNS = [
    "age", "sex", "cp", "trestbps", "chol", "fbs", "restecg",
    "thalach", "exang", "oldpeak", "slope", "ca", "thal",
]
TARGET_COLUMN = "target"


def load_data(csv_path: str) -> pd.DataFrame:
    """Load the dataset from a CSV file."""
    df = pd.read_csv(csv_path, encoding="utf-8-sig")
    df.columns = [c.strip() for c in df.columns]
    return df


def clean_data(df: pd.DataFrame) -> pd.DataFrame:
    """Basic cleaning: drop duplicates and rows with missing values."""
    df = df.drop_duplicates()
    df = df.dropna()
    return df


def split_features_target(df: pd.DataFrame):
    """Split dataframe into feature matrix X and target vector y."""
    X = df[FEATURE_COLUMNS]
    y = df[TARGET_COLUMN]
    return X, y


def prepare_train_test(csv_path: str, test_size: float = 0.2, random_state: int = 42):
    """
    Full preprocessing pipeline: load -> clean -> split -> scale.
    Returns X_train, X_test, y_train, y_test, and the fitted scaler.
    """
    df = load_data(csv_path)
    df = clean_data(df)
    X, y = split_features_target(df)

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=test_size, random_state=random_state, stratify=y
    )

    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)

    return X_train_scaled, X_test_scaled, y_train, y_test, scaler


if __name__ == "__main__":
    df = load_data("data/heart.csv")
    df = clean_data(df)
    print(f"Dataset shape after cleaning: {df.shape}")
    print(f"Target distribution:\n{df[TARGET_COLUMN].value_counts()}")
