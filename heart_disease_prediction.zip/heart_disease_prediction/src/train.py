"""
train.py
--------
Trains and compares several classification models for heart disease
prediction, then saves the best-performing model (plus the scaler)
to disk for later use in predict.py.

Run:
    python src/train.py
"""

import os
import sys
import joblib
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.svm import SVC
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score,
    f1_score, roc_auc_score, confusion_matrix, classification_report,
)

sys.path.append(os.path.dirname(__file__))
from preprocess import prepare_train_test  # noqa: E402

DATA_PATH = os.path.join(os.path.dirname(__file__), "..", "data", "heart.csv")
MODEL_DIR = os.path.join(os.path.dirname(__file__), "..", "model")


def get_models():
    """Return a dict of candidate models to compare."""
    return {
        "Logistic Regression": LogisticRegression(max_iter=1000, random_state=42),
        "Decision Tree": DecisionTreeClassifier(max_depth=5, random_state=42),
        "Random Forest": RandomForestClassifier(n_estimators=200, random_state=42),
        "SVM (RBF)": SVC(kernel="rbf", probability=True, random_state=42),
        "K-Nearest Neighbors": KNeighborsClassifier(n_neighbors=7),
    }


def evaluate_model(model, X_test, y_test):
    """Compute standard classification metrics for a fitted model."""
    y_pred = model.predict(X_test)
    y_proba = model.predict_proba(X_test)[:, 1] if hasattr(model, "predict_proba") else None

    metrics = {
        "accuracy": accuracy_score(y_test, y_pred),
        "precision": precision_score(y_test, y_pred),
        "recall": recall_score(y_test, y_pred),
        "f1": f1_score(y_test, y_pred),
    }
    if y_proba is not None:
        metrics["roc_auc"] = roc_auc_score(y_test, y_proba)
    return metrics, y_pred


def main():
    print("Loading and preprocessing data...")
    X_train, X_test, y_train, y_test, scaler = prepare_train_test(DATA_PATH)

    models = get_models()
    results = []
    fitted_models = {}

    print("\nTraining and evaluating models...\n")
    for name, model in models.items():
        model.fit(X_train, y_train)
        metrics, y_pred = evaluate_model(model, X_test, y_test)
        metrics["model"] = name
        results.append(metrics)
        fitted_models[name] = model

        print(f"--- {name} ---")
        for k, v in metrics.items():
            if k != "model":
                print(f"  {k:10s}: {v:.4f}")
        print()

    results_df = pd.DataFrame(results).set_index("model").sort_values(
        "f1", ascending=False
    )
    print("=" * 50)
    print("Model comparison (sorted by F1 score):")
    print("=" * 50)
    print(results_df.round(4).to_string())

    best_name = results_df.index[0]
    best_model = fitted_models[best_name]
    print(f"\nBest model: {best_name}")

    y_pred = best_model.predict(X_test)
    print("\nClassification report for best model:")
    print(classification_report(y_test, y_pred, target_names=["No Disease", "Disease"]))
    print("Confusion matrix:")
    print(confusion_matrix(y_test, y_pred))

    os.makedirs(MODEL_DIR, exist_ok=True)
    joblib.dump(best_model, os.path.join(MODEL_DIR, "heart_disease_model.pkl"))
    joblib.dump(scaler, os.path.join(MODEL_DIR, "scaler.pkl"))
    joblib.dump(best_name, os.path.join(MODEL_DIR, "model_name.pkl"))
    print(f"\nSaved best model ('{best_name}') and scaler to '{MODEL_DIR}/'")


if __name__ == "__main__":
    main()
